# ================================================================================
# ASESORÍA II — LAMBDA ANALYTICS (Byron Cornejo et al.)
# Comparación estadística de la sismicidad de Chile y Japón (USGS, 2000-2025)
# ================================================================================
#
# Este script une, en un solo archivo reproducible, los dos scripts originales
# del equipo:
#   1) Asesoria_I.R       -> PARTE A: carga, limpieza y análisis descriptivo
#                             (corresponde a la Sección 5 del informe).
#   2) declustering_o.o.R -> PARTE B: declustering de Zaliapin & Ben-Zion (2020)
#                             y todo el desarrollo inferencial de Asesoría 2
#                             (corresponde a la Sección 6 del informe).
#
# Respecto a los scripts originales, este archivo:
#   - Consolida TODAS las librerías al inicio (antes estaban repartidas en
#     medio del código: patchwork, DescTools, KScorrect, tseries, purrr,
#     twosamples, tibble aparecían recién cuando se necesitaban por primera
#     vez, y algunas se cargaban más de una vez).
#   - Fija UNA sola semilla global, set.seed(2026), justo después de cargar
#     las librerías (Sección 1.2) — igual que el script original de
#     declustering. IMPORTANTE, corregido en esta versión: una revisión
#     anterior de este archivo agregaba ADEMÁS un set.seed() nuevo
#     inmediatamente antes de cada llamada de producción a
#     declustering_zbz() (Sección B.8), pensando que reforzaba la
#     reproducibilidad. Eso fue un error: al reiniciar la semilla justo ahí,
#     el generador aleatorio arranca "de cero" en ese punto en vez de
#     continuar la secuencia que ya venía consumiendo explorar_alpha0()
#     (Sección B.8) desde el set.seed(2026) inicial — es decir, produce una
#     realización aleatoria DISTINTA a la que generó los números que ya están
#     en el informe entregado, aunque sea igual de "válida" estadísticamente.
#     Se eliminaron esos dos set.seed() adicionales: el único set.seed(2026)
#     del inicio del script es suficiente para reproducibilidad, SIEMPRE que
#     el script se corra completo, de principio a fin, en una sesión de R
#     recién iniciada (sin haber ejecutado antes ninguna otra línea que
#     consuma aleatoriedad) y sin reordenar el código que va antes de las
#     llamadas de producción de declustering_zbz() (Sección B.8) — la Parte A
#     no usa aleatoriedad en ningún punto, así que no afecta esta cadena.
#     Ver Sección B.8 para el detalle y la advertencia de uso.
#   - Elimina duplicaciones detectadas en el script original: la función
#     productividad_vs_magnitud() estaba definida y llamada dos veces de
#     forma idéntica; el filtro de chile_fuerte65/japon_fuerte65 aparecía dos
#     veces; había dos funciones distintas llamadas igual ("siegel_tukey"),
#     lo que hacía que la segunda definición sobreescribiera silenciosamente
#     a la primera (se renombraron para dejar ambas disponibles sin choque).
#   - Reordena código que en el original se usaba ANTES de estar definido
#     (ej.: dt_chile/dt_japon y fondo_chile/fondo_japon se usaban ~470 líneas
#     antes de calcularse; tiempos_entre_eventos() se llamaba antes de
#     definirse). Aquí cada función y cada variable se define antes de su
#     primer uso, para que el script corra de principio a fin sin errores.
#   - Retira el bloque de la Sección 13 original (grilla de un solo sorteo
#     por alpha0), que estaba envuelto en if(FALSE){...} y nunca se ejecutaba
#     — quedó reemplazada por la batería multi-realización (Sección B.16).
#   - Agrega comentarios línea a línea / función a función explicando qué
#     hace cada bloque, pensados para que cualquier integrante del equipo (o
#     el ayudante del curso) pueda seguir el código sin haber escrito el
#     original.
#   - Reconstruye dos objetos (moderate_chile/moderate_japon y
#     tabla_fosa_depth) y dos comparaciones (ks_dt/mw_dt) que el script de
#     declustering original USABA pero nunca calculaba explícitamente en el
#     archivo entregado — probablemente porque en la sesión de RStudio del
#     autor ya existían en el entorno de una corrida anterior. Quedan
#     marcadas con "[RECONSTRUIDO]" en el comentario correspondiente: la
#     lógica sigue exactamente el patrón del resto del script, pero conviene
#     que el equipo verifique que los números resultantes calzan con los
#     Cuadros 27-31 del informe antes de dar el script por definitivo.
#
# ESTRUCTURA DEL ARCHIVO:
#   0. Librerías y configuración global (semillas, rutas, paletas y temas)
#   PARTE A — Asesoría I: carga, limpieza y análisis descriptivo (Sección 5)
#   PARTE B — Asesoría II: declustering e inferencia (Sección 6)
# ================================================================================


# ================================================================================
# 0. LIBRERÍAS (todas las que usa el script completo, cargadas una sola vez)
# ================================================================================

# Si falta alguna, instálala una sola vez (no se deja un install.packages()
# automático dentro del script: no es buena práctica que un script de
# análisis reproducible instale paquetes por su cuenta cada vez que se
# corre). Descomenta la línea siguiente la primera vez que uses el script
# en un computador nuevo:
# install.packages(c("MASS","lubridate","dplyr","stringr","ggplot2","sf",
#                     "rnaturalearth","ineq","tidyr","readr","ggridges",
#                     "mclust","patchwork","DescTools","KScorrect","tseries",
#                     "purrr","twosamples","tibble","scales","knitr"))

library(MASS)          # glm.nb() (Binomial Negativa, Sección B.31)
library(lubridate)     # manejo de fechas (year(), month(), floor_date(), etc.)
library(dplyr)         # verbos de manipulación de datos (filter, mutate, ...)
library(stringr)       # str_detect(), usado para filtrar por país en 'place'
library(ggplot2)       # todos los gráficos
library(sf)            # manejo de geometrías espaciales (fosas, mapas)
library(rnaturalearth) # polígonos de países para los mapas
library(ineq)          # curvas de Lorenz (Sección A.9)
library(tidyr)         # pivot_longer/pivot_wider, complete(), etc.
library(readr)         # read_csv() / write_csv()
library(ggridges)      # gráficos ridgeline (por fosa, por país)
library(mclust)        # mezcla de 2 gaussianas para estimar eta0 (Sección B.4)
library(patchwork)     # combinar paneles de ggplot en una sola figura
library(DescTools)     # SiegelTukeyTest() (test de dispersión)
library(KScorrect)     # LcKS(): bondad de ajuste exponencial (Lilliefors-KS)
library(tseries)       # adf.test() (Dickey-Fuller aumentado)
library(purrr)         # map_dfr(), usado en Ljung-Box y en los Z-test por fosa
library(twosamples)    # cvm_test() y ad_test() (Cramér-von Mises, Anderson-Darling)
library(tibble)        # tibble(), column_to_rownames(), rownames_to_column()
library(scales)        # label_number() en los ejes log de los gráficos de tiempos
library(knitr)         # kable(), para las tablas finales del informe

# --- Blindaje contra choques de nombres con OTRAS librerías de tu sesión ---
# Si en tu sesión de RStudio ya tenías cargada, en algún momento antes de
# correr este script, una librería como "plyr" (u otra) que también define
# funciones llamadas count()/select()/filter()/rename()/summarise()/mutate()/
# arrange()/group_by(), esa otra versión puede quedar "tapando" a la de
# dplyr y romper el script con errores como:
#   Error en count(., Pais, mes) : el argumento no fue usado (mes)
# porque la función que R termina usando no es dplyr::count() sino la de la
# otra librería, que espera argumentos distintos. Para que el script funcione
# sin importar qué más tengas cargado en tu sesión, se reasignan acá estos
# nombres explícitamente a la versión de dplyr (se hace UNA vez, después de
# cargar todas las librerías, para que quede como la versión "definitiva"
# durante el resto del script). Si te vuelve a pasar un error de este tipo
# con otra función, la solución es la misma: <nombre> <- dplyr::<nombre>.
select    <- dplyr::select
filter    <- dplyr::filter
count     <- dplyr::count
rename    <- dplyr::rename
summarise <- dplyr::summarise
summarize <- dplyr::summarize
mutate    <- dplyr::mutate
arrange   <- dplyr::arrange
group_by  <- dplyr::group_by


# ================================================================================
# 1. CONFIGURACIÓN GLOBAL: rutas, semillas, paletas y temas compartidos
# ================================================================================

# --- 1.1 Rutas de datos -------------------------------------------------------
# Ajusta esta única variable si cambias de computador; todo el script arma
# las rutas de los 5 archivos a partir de ella.
#
# Ruta RELATIVA a la carpeta "data/" incluida en este repositorio. Para que
# esto funcione, tu directorio de trabajo de R debe ser la raíz del
# repositorio (donde está este script) al momento de correrlo -si abres el
# repo como carpeta/proyecto en RStudio esto ya queda así automáticamente;
# si no, corre primero setwd("ruta/a/asesoria2-sismicidad-chile-japon").
RUTA_DATOS <- "data/"

RUTA_CHILE_00_25   <- paste0(RUTA_DATOS, "Chile00-25.csv")
RUTA_JAPON_00_25   <- paste0(RUTA_DATOS, "Japon00-25.csv")
RUTA_CHILE_90_25   <- paste0(RUTA_DATOS, "Chile90-25.csv")
RUTA_JAPON_90_25   <- paste0(RUTA_DATOS, "Japon90-25.csv")
RUTA_TRENCH_SHP    <- paste0(RUTA_DATOS, "PLATES_PlateBoundary_ArcGIS/trench.shp")

# --- 1.1.1 Modo reproducción del informe (agregado 2026-07-12) ----------------
# PROBLEMA que resuelve esto: declustering_zbz() (Sección B.8) tiene dos pasos
# aleatorios sin semilla propia (calcular_alpha() y el thinning final), así
# que aunque el script use set.seed(2026) al principio, CUALQUIER cambio en
# cuántos sorteos aleatorios ocurren antes de la Sección B.8 -incluido correr
# el script en fragmentos, en distinta versión de R, o con una sola línea de
# diferencia arriba- produce una realización distinta a la que efectivamente
# generó los Cuadros y Figuras que ya están en el informe entregado. En la
# práctica esto hizo IMPOSIBLE reproducir bit-a-bit los números del informe
# solo re-corriendo el código.
#
# SOLUCIÓN: en vez de volver a sortear el declustering, este modo CARGA los
# catálogos ya declusterizados que el script exportó la vez que generó el
# informe (chile_declusterizado_completo_con_colchon.csv /
# japon_declusterizado_completo_con_colchon.csv, vía write_csv en la Sección
# B.10 más abajo) y salta directo a la Sección B.8.1 en adelante. Esa parte
# del pipeline (reasignación de generador, filtro de período de estudio,
# tabla de productividad, y todos los Cuadros/Figuras de la Sección 6) es
# 100% determinística -no usa runif/sample en ningún punto-, así que cargar
# el catálogo congelado reproduce EXACTAMENTE los mismos resultados del
# informe, sin depender de la suerte de que la semilla caiga igual.
#
# Verificado contra el informe entregado (Asesoria_II_LambdaAnalytics.pdf,
# Cuadro 11/12): los 5 generadores con más réplicas de Chile (440, 148, 115,
# 43, 21) y de Japón (807, 88, 77, 67, 31) coinciden exactamente en cantidad
# de réplicas con los catálogos congelados de abajo -solo cambiaba la
# ETIQUETA del generador (raíz temporal vs. mayor magnitud), que es
# justamente lo que corrige la Sección B.8.1.
#
# Pon esto en FALSE si en cambio quieres correr el declustering desde cero
# (por ejemplo, para generar resultados NUEVOS a futuro, no para reproducir
# el informe ya entregado). Con FALSE, el resultado dependerá de la cadena
# aleatoria completa desde el set.seed(2026) inicial, tal como se explica en
# la Sección 1.2 de abajo.
MODO_REPRODUCCION_INFORME <- TRUE

RUTA_CHILE_DECL_COLCHON <- paste0(RUTA_DATOS, "chile_declusterizado_completo_con_colchon.csv")
RUTA_JAPON_DECL_COLCHON <- paste0(RUTA_DATOS, "japon_declusterizado_completo_con_colchon.csv")

# --- 1.2 Semilla global --------------------------------------------------------
# Semilla ÚNICA del script completo (idéntica a la que ya traía
# declustering_o.o.R). A partir de acá, TODO sorteo aleatorio que ocurra en
# cualquier parte del script —incluida la corrida de producción del
# declustering en la Sección B.8, el paso que más importa reproducir tal
# cual— queda determinado por esta semilla y por el orden exacto en que se
# ejecuta el código. La Parte A no usa aleatoriedad en ningún punto, así que
# no consume nada de esta semilla antes de llegar a la Parte B.
#
# Para que la corrida sea IDÉNTICA a la que generó los números que ya están
# en el informe entregado, es necesario correr este script COMPLETO, de
# principio a fin, en una sesión de R recién iniciada (Session > Restart R
# en RStudio antes de correrlo) — no reordenar bloques, no volver a correr
# líneas sueltas de la Parte B por separado, y no insertar código nuevo que
# consuma aleatoriedad (runif/sample/rnorm/etc.) antes de la Sección B.8. La
# versión anterior de este script agregaba, además de esta semilla, un
# segundo set.seed() justo antes de cada llamada de producción a
# declustering_zbz() (Sección B.8): eso fue un ERROR (ya corregido) — reseteaba
# el generador aleatorio a mitad de camino y producía una realización
# distinta a la que efectivamente está en el informe. Ver Sección B.8.
#
# RNGkind() FIJO explícitamente (no solo la semilla): una misma semilla NO
# garantiza el mismo resultado en dos instalaciones de R distintas si el
# ALGORITMO de muestreo por defecto es distinto entre ellas. El caso más
# común: R cambió el algoritmo por defecto de sample() en la versión 3.6.0
# ("Rounding" -> "Rejection") — si en un computador tienen R < 3.6.0 y en
# otro R >= 3.6.0 (o viceversa), CUALQUIER función que use sample() por
# dentro (en este script: luen_stark_pvalue(), Sección B.7; y posiblemente
# Mclust() de la Sección B.4, que puede submuestrear con sample() si el
# catálogo de un país supera el umbral interno de mclust) va a consumir el
# generador aleatorio de forma distinta en cada computador, y a partir de
# ahí TODO lo que dependa de esa función en adelante se desincroniza —
# aunque el código y la semilla sean idénticos. Fijar el algoritmo acá,
# explícitamente, hace que ambos computadores usen el mismo método sin
# importar qué versión de R tenga cada uno instalada (siempre que ambas
# sean R >= 3.6.0; si alguna de las dos es más antigua que eso, esta línea
# no alcanza a igualarlas — hay que actualizar esa instalación de R).
RNGkind(kind = "Mersenne-Twister", normal.kind = "Inversion", sample.kind = "Rejection")
set.seed(2026)

# --- 1.3 Paletas de color compartidas (idénticas en ambos scripts originales) --
paleta_pais  <- c("Chile" = "#F8766D", "Japón" = "#619CFF")
paleta_mw    <- c("Minor" = "#D6EAF8", "Light" = "#AED6F1", "Moderate" = "#5DADE2",
                   "Strong" = "#2874A6", "Major" = "#154360", "Great" = "red")
paleta_depth <- c("Poco profunda" = "#1f78b4", "Intermedia" = "#ff7f00", "Profunda" = "#e31a1c")

# Paleta usada solo en los gráficos de la batería de Fase 0 (Sección B.16)
paleta_tests <- c("KS (estacionariedad)" = "#2a78d6",
                   "Bridge (estacionariedad)" = "#e34948",
                   "Luen-Stark (espacio-tiempo)" = "#4a3aa7")

# --- 1.4 Temas de ggplot ---------------------------------------------------
# tema_base: usado en los gráficos "grandes" de estilo informe (Parte A y la
# mayoría de la Parte B).
tema_base <- theme_minimal() +
  theme(
    plot.title   = element_text(size = 20, face = "bold", hjust = 0.5),
    axis.title   = element_text(size = 16, face = "bold"),
    axis.text    = element_text(size = 14),
    legend.title = element_text(size = 16, face = "bold"),
    legend.text  = element_text(size = 14)
  )

# tema_base_decl: tema más compacto (usado originalmente solo dentro del
# script de declustering, para las figuras diagnósticas de Fase 0: GMM,
# curva de sensibilidad, batería multi-realización). Se le cambió el nombre
# respecto al original (donde también se llamaba "tema_base") para que no
# sobreescriba silenciosamente al tema de la Parte A si el script se corre
# por bloques en una sesión interactiva.
tema_base_decl <- theme_minimal() +
  theme(
    plot.title    = element_text(size = 16, face = "bold"),
    plot.subtitle = element_text(size = 11, color = "grey40"),
    axis.title    = element_text(size = 13, face = "bold"),
    axis.text     = element_text(size = 11),
    legend.title  = element_blank(),
    legend.text   = element_text(size = 11),
    legend.position = "top"
  )


# ################################################################################
# PARTE A — ASESORÍA I: CARGA, LIMPIEZA Y ANÁLISIS DESCRIPTIVO (Sección 5)
# ################################################################################

# ================================================================================
# A.1 CARGA DE DATOS (catálogo 2000-2025, el usado para todo el análisis
#     descriptivo de la Asesoría 1 / Sección 5 del informe)
# ================================================================================

chile_raw_A <- read_csv(RUTA_CHILE_00_25, show_col_types = FALSE) %>% mutate(Pais = "Chile")
japon_raw_A <- read_csv(RUTA_JAPON_00_25, show_col_types = FALSE) %>% mutate(Pais = "Japón")

# Polígonos de las fosas de subducción (shapefile del Plate Boundary dataset)
#
# NOTA: este shapefile NO se incluye en el repositorio (no estaba entre los
# archivos disponibles al armar esta carpeta). Si al correr esto te aparece
# este error, copia tu carpeta "PLATES_PlateBoundary_ArcGIS" (con
# trench.shp + los archivos .dbf/.shx/.prj/etc. que la acompañan) dentro de
# data/, o ajusta RUTA_TRENCH_SHP arriba para que apunte a donde la
# tengas guardada. Sin este archivo, la Sección A.2 en adelante (distancia a
# la fosa, y todo lo que depende de la columna 'fosa'/'fosa_label' -Secciones
# A.11 a A.15, más B.26 en la Parte B) no puede calcularse.
if (!file.exists(RUTA_TRENCH_SHP)) {
  stop(
    "No se encontró el shapefile de fosas en: ", RUTA_TRENCH_SHP, "\n",
    "Copia la carpeta 'PLATES_PlateBoundary_ArcGIS' (trench.shp + sus archivos ",
    "acompañantes .dbf/.shx/.prj) dentro de la carpeta data/ de este repositorio, ",
    "o ajusta RUTA_TRENCH_SHP en la Sección 1.1 para que apunte a su ubicación real."
  )
}
trench <- st_read(RUTA_TRENCH_SHP, quiet = TRUE)

# ================================================================================
# A.2 FOSA MÁS CERCANA Y DISTANCIA A CADA SISMO
# ================================================================================

# Nos quedamos solo con las fosas relevantes para Chile y Japón, y unificamos
# los 3 segmentos de la fosa chilena bajo una sola etiqueta ("PERU-CHILE
# TRENCH"), porque para efectos de este análisis nos interesa el sistema de
# subducción como unidad, no el segmento geográfico exacto.
trench_estudio <- trench %>%
  filter(
    geogdesc %in% c(
      "PERU-CHILE TRENCH", "CHILE TRENCH", "SOUTHERNMOST CHILE TRENCH",
      "KURIL TRENCH", "JAPAN TRENCH", "BONIN TRENCH", "NANKAI TROUGH",
      "RYUKU TRENCH"   # sic: typo original del shapefile ("RYUKU" en vez de
                        # "RYUKYU"); se corrige más abajo, en A.11.1, solo
                        # para la ETIQUETA de despliegue (fosa_label), sin
                        # tocar la columna 'fosa' que se usa en los cálculos.
    )
  ) %>%
  mutate(
    fosa = case_when(
      geogdesc %in% c("PERU-CHILE TRENCH", "CHILE TRENCH", "SOUTHERNMOST CHILE TRENCH") ~ "PERU-CHILE TRENCH",
      TRUE ~ geogdesc
    )
  )

# CRS métrico (Web Mercator, EPSG:3857) para poder calcular distancias en metros
trench_m <- st_transform(trench_estudio, 3857)

# --- Función reutilizable: para cada sismo, encuentra la fosa más cercana y
#     la distancia en km. Se usa tanto acá (catálogo 2000-2025) como más
#     adelante, en B.26, sobre el catálogo declusterizado. ---
calcular_fosa_cercana <- function(df, trench_m) {

  # Convertimos los sismos (lon/lat) a objeto espacial (sf), conservando
  # longitude/latitude como columnas normales además de la geometría.
  sismos_sf <- st_as_sf(df, coords = c("longitude", "latitude"), crs = 4326, remove = FALSE)

  # Reproyectamos a un CRS métrico para que las distancias queden en metros
  sismos_m <- st_transform(sismos_sf, 3857)

  # Matriz de distancias: cada sismo contra cada fosa
  distancias <- st_distance(sismos_m, trench_m)

  # Para cada sismo (fila), el índice de la fosa más cercana y esa distancia mínima
  indice_fosa <- apply(distancias, 1, which.min)
  dist_min    <- apply(distancias, 1, min)

  # Agregamos las dos variables nuevas al data frame original (distancia en km)
  df$fosa         <- trench_m$fosa[indice_fosa]
  df$dist_fosa_km <- round(as.numeric(dist_min) / 1000, 2)

  df
}

# Aplicamos la función a cada país por separado
Japon00_25 <- calcular_fosa_cercana(japon_raw_A, trench_m)
Chile00_25 <- calcular_fosa_cercana(chile_raw_A, trench_m)

# Revisión rápida de resultados
head(Japon00_25[, c("latitude", "longitude", "fosa", "dist_fosa_km")])
head(Chile00_25[, c("latitude", "longitude", "fosa", "dist_fosa_km")])

# ================================================================================
# A.3 UNIFICACIÓN Y PROCESAMIENTO DE DATOS
# ================================================================================
# Une Chile y Japón en un solo data frame, filtra registros fuera de alcance
# (eventos mal geolocalizados como "Chile-Argentina" o tipos de magnitud no
# homologables: local 'ml'/'m'), y construye las variables derivadas que se
# usan en todo el resto del informe.

datos <- bind_rows(Chile00_25, Japon00_25) %>%
  filter(
    (Pais == "Chile" & str_detect(place, "Chile") & !str_detect(place, "Argentina")) |
      (Pais == "Japón" & str_detect(place, "Japan")),
    !(magType %in% c("m", "ml"))
  ) %>%
  mutate(
    # Variable tricotomizada de profundidad (cortes: 70 km y 300 km)
    depth_cat = case_when(
      depth < 70 ~ "Poco profunda",
      depth >= 70 & depth < 300 ~ "Intermedia",
      depth >= 300 & depth <= 700 ~ "Profunda",
      TRUE ~ NA_character_
    ),
    # Homogenización de todas las magnitudes a escala Momento (Mw), usando
    # las fórmulas de conversión estándar según el tipo de magnitud reportado
    # por USGS (mw* ya viene en Mw; ms y mb se convierten con las fórmulas
    # empíricas válidas en su rango de aplicación).
    transMw = case_when(
      magType %in% c("mw", "mwb", "mwc", "mwr", "mww") ~ mag,
      magType == "ms" & mag >= 3.0 & mag <= 6.1 ~ 0.67 * mag + 2.07,
      magType == "ms" & mag >= 6.2 & mag <= 8.2 ~ 0.99 * mag + 0.08,
      magType == "mb" & mag >= 3.5 & mag <= 6.7 ~ 0.85 * mag + 1.03,
      TRUE ~ NA_real_
    ),
    # Categorización estándar de magnitud (escala USGS: Minor a Great)
    Mw_cat = factor(case_when(
      transMw >= 3 & transMw < 4 ~ "Minor",
      transMw >= 4 & transMw < 5 ~ "Light",
      transMw >= 5 & transMw < 6 ~ "Moderate",
      transMw >= 6 & transMw < 7 ~ "Strong",
      transMw >= 7 & transMw < 8 ~ "Major",
      transMw >= 8              ~ "Great",
      TRUE ~ NA_character_
    ), levels = c("Minor", "Light", "Moderate", "Strong", "Major", "Great")),
    year = year(time)
  )

# Verificación inicial: qué tipos de magnitud quedaron por país
with(datos, table(Pais, magType))

# ================================================================================
# A.4 MAPAS GEORREFERENCIADOS
# ================================================================================

world <- ne_countries(scale = "medium", returnclass = "sf")

generar_mapa <- function(pais_nombre, xlims, ylims, r_size, forma_base, titulo) {

  paleta_formas <- c("Moderate" = 21, "Strong" = 22, "Major" = 24, "Great" = 23)

  ggplot() +
    geom_sf(data = world, fill = "grey90", color = "grey40", linewidth = 0.2) +
    # Solo se grafican sismos Mw >= 5 (bajo ese umbral el mapa se satura de puntos)
    geom_point(data = datos %>% filter(Pais == pais_nombre, transMw >= 5),
               aes(x = longitude, y = latitude, size = transMw, fill = depth_cat, shape = Mw_cat),
               color = "black", stroke = 0.3, alpha = 0.8) +
    coord_sf(xlim = xlims, ylim = ylims, expand = FALSE) +
    scale_size_continuous(name = NULL, range = r_size, guide = "none") +
    scale_fill_manual(values = paleta_depth, name = "Profundidad") +
    scale_shape_manual(values = paleta_formas, name = "Categoría Mag", drop = TRUE) +
    labs(title = titulo, x = "Longitud", y = "Latitud") +
    theme_minimal() +
    theme(
      plot.title = element_text(size = 18, face = "bold", hjust = 0.5),
      axis.title = element_text(size = 16, face = "bold"),
      axis.text  = element_text(size = 10),
      legend.title = element_text(size = 19, face = "bold"),
      legend.text  = element_text(size = 17),
      panel.grid.major = element_line(colour = "grey80", linewidth = 0.3)
    ) +
    guides(
      fill  = guide_legend(override.aes = list(shape = forma_base, size = 5)),
      shape = guide_legend(override.aes = list(size = 4, fill = "grey70"))
    )
}

print(generar_mapa("Chile", c(-80, -65), c(-55, -17), c(1, 5), forma_base = 22,
                    "Sismicidad de Chile (Mw ≥ 5, 2000-2025)"))
print(generar_mapa("Japón", c(120, 148), c(22, 50), c(1, 8), forma_base = 24,
                    "Sismicidad de Japón (Mw ≥ 5, 2000-2025)"))

# ================================================================================
# A.5 ESTADÍSTICAS DESCRIPTIVAS Y TABLAS DE CONTINGENCIA
# ================================================================================

# Resumen numérico (n, media, DE, mín, cuartiles, máx) de transMw y depth
resumen_cuant <- function(data) {
  data %>%
    select(where(is.numeric) & c(depth, transMw)) %>%
    summarise(across(everything(), list(
      n = ~sum(!is.na(.)), Media = ~mean(., na.rm = TRUE), DE = ~sd(., na.rm = TRUE),
      Min = ~min(., na.rm = TRUE), Q25 = ~quantile(., 0.25, na.rm = TRUE),
      Mediana = ~median(., na.rm = TRUE), Q75 = ~quantile(., 0.75, na.rm = TRUE), Max = ~max(., na.rm = TRUE)
    ))) %>%
    pivot_longer(everything(), names_to = c("Variable", ".value"), names_sep = "_")
}

print(resumen_cuant(datos %>% filter(Pais == "Chile")))
print(resumen_cuant(datos %>% filter(Pais == "Japón")))

# Tablas de frecuencias relativas para variables categóricas, generadas de
# forma automática para no repetir el mismo bloque 6 veces
cats <- c("status", "type", "locationSource", "magSource", "depth_cat", "Mw_cat")
tablas <- lapply(cats, function(v) {
  datos %>%
    group_by(Pais, across(all_of(v))) %>%
    summarise(Frecuencia = n(), .groups = "drop_last") %>%
    mutate(Porcentaje = round(100 * Frecuencia / sum(Frecuencia), 2))
})
names(tablas) <- cats

print(tablas$depth_cat)
print(tablas$Mw_cat)

# Resumen detallado de profundidad, desagregado por categoría de profundidad
print(
  datos %>%
    group_by(Pais, depth_cat) %>%
    summarise(n = n(), Media = mean(depth, na.rm = TRUE), DE = sd(depth, na.rm = TRUE),
              Min = min(depth, na.rm = TRUE), Q1 = quantile(depth, 0.25, na.rm = TRUE),
              Mediana = median(depth, na.rm = TRUE), Q3 = quantile(depth, 0.75, na.rm = TRUE),
              Max = max(depth, na.rm = TRUE), .groups = "drop")
)

# ================================================================================
# A.6 ANÁLISIS GRÁFICO: CAJAS, VIOLINES Y DENSIDADES
# ================================================================================

graficar_box_violin <- function(y_var, ylab, titulo, ylims = NULL, t_size = 22) {
  p <- ggplot(datos, aes(x = Pais, y = .data[[y_var]], fill = Pais)) +
    geom_violin(alpha = 0.35, colour = NA, trim = FALSE) +
    geom_boxplot(width = 0.18, colour = "black", alpha = 0.8, outlier.shape = 21, outlier.size = 2) +
    stat_summary(fun = median, geom = "point", shape = 23, size = 0, fill = "yellow") +
    scale_fill_manual(values = paleta_pais) +
    labs(title = titulo, x = "", y = ylab) +
    tema_base + theme(legend.position = "none", panel.grid.major.x = element_blank(),
                       plot.title = element_text(size = t_size, face = "bold", hjust = 0.5))
  if (!is.null(ylims)) p <- p + coord_cartesian(ylim = ylims)
  print(p)
}

graficar_box_violin("transMw", expression(M[w]), "Comparación de la Magnitud de Momento")
graficar_box_violin("depth", "Profundidad (km)", "Comparación de la Profundidad de los Sismos",
                     c(0, 350), t_size = 15)

# Distribución de la profundidad según categoría de profundidad y país, en un
# solo gráfico (6 grupos: 3 categorías x 2 países)
print(
  datos %>%
    mutate(Grupo = factor(paste(depth_cat, Pais),
                           levels = c("Poco profunda Chile", "Poco profunda Japón",
                                      "Intermedia Chile", "Intermedia Japón",
                                      "Profunda Chile", "Profunda Japón"))) %>%
    ggplot(aes(x = Grupo, y = depth, fill = Pais)) +
    geom_violin(alpha = 0.3, colour = NA, trim = FALSE) +
    geom_boxplot(width = 0.18, colour = "black", alpha = 0.8, outlier.shape = 21, outlier.size = 2) +
    scale_fill_manual(values = paleta_pais) +
    scale_y_continuous(breaks = seq(0, 700, 100)) + coord_cartesian(ylim = c(0, 700)) +
    labs(title = "Distribución de la profundidad según categoría y país", x = "", y = "Profundidad (km)", fill = "País") +
    tema_base + theme(axis.text.x = element_text(size = 12, angle = 20, hjust = 1))
)

graficar_densidad <- function(x_var, xlab, titulo, facet_var = NULL, filtrar_mw = FALSE) {
  df_plot <- if (filtrar_mw) datos %>% filter(Mw_cat %in% c("Moderate", "Strong", "Major")) else datos
  p <- ggplot(df_plot, aes(x = .data[[x_var]], fill = Pais, colour = Pais)) +
    geom_density(alpha = 0.35, linewidth = 1.2, adjust = if (x_var == "transMw") 1.2 else 1) +
    scale_fill_manual(values = paleta_pais) + scale_colour_manual(values = paleta_pais) +
    labs(title = titulo, x = xlab, y = "Densidad", fill = "País", colour = "País") +
    tema_base + theme(plot.title = element_text(size = if (is.null(facet_var)) 20 else 15, face = "bold", hjust = 0.5))

  if (!is.null(facet_var)) {
    f_levels <- if (facet_var == "Mw_cat") c("Moderate", "Strong", "Major") else unique(datos[[facet_var]])
    p <- p + facet_wrap(vars(factor(.data[[facet_var]], levels = f_levels)), nrow = 1, scales = "free_y") +
      theme(strip.text = element_text(size = 16, face = "bold"))
  }
  print(p)
}

graficar_densidad("transMw", expression(M[w]), "Distribución de la Magnitud de Momento")
graficar_densidad("transMw", expression(M[w]), "Distribución de la Magnitud de Momento según Profundidad", "depth_cat")
graficar_densidad("depth", "Profundidad (km)", "Distribución de la Profundidad de los Sismos")
graficar_densidad("depth", "Profundidad (km)", "Distribución de la Profundidad según Magnitud", "Mw_cat", filtrar_mw = TRUE)

# ================================================================================
# A.7 ANÁLISIS DE FRECUENCIAS Y PROPORCIONES (gráficos de barras)
# ================================================================================

print(
  ggplot(datos, aes(x = year, fill = Mw_cat)) +
    geom_bar() + facet_wrap(~Pais, ncol = 1) +
    labs(title = "Frecuencia anual según categoría de magnitud", x = "Año", y = "Número de sismos", fill = "Categoría") +
    theme_minimal()
)

graficar_barras_prop <- function(x_var, fill_var, paleta, titulo, xlab, ylab) {
  ggplot(datos, aes(x = .data[[x_var]], fill = .data[[fill_var]])) +
    geom_bar(position = "fill") + facet_wrap(~Pais, ncol = if (x_var == "year") 1 else NULL) +
    scale_fill_manual(values = paleta) +
    labs(title = titulo, x = xlab, y = ylab, fill = fill_var) +
    tema_base + theme(axis.text = element_text(size = 18), strip.text = element_text(size = 18, face = "bold"))
}

print(graficar_barras_prop("year", "Mw_cat", paleta_mw, "Proporción anual según categoría de magnitud", "Año", "Proporción"))
print(graficar_barras_prop("depth_cat", "Mw_cat", paleta_mw, "Magnitud según categoría de profundidad", "Profundidad", "Proporción"))
print(graficar_barras_prop("Mw_cat", "depth_cat", c("Poco profunda" = "#9ECAE1", "Intermedia" = "#4292C6", "Profunda" = "#084594"),
                            "Distribución de la profundidad según magnitud", "Categoría de magnitud", "Proporción"))

# ================================================================================
# A.8 ANÁLISIS DE SERIES TEMPORALES (descriptivo, catálogo crudo 2000-2025)
# ================================================================================

preparar_ts <- function(df) {
  df %>%
    mutate(mes = floor_date(time, "month")) %>%
    count(Pais, mes) %>%
    group_by(Pais) %>%
    complete(mes = seq(min(mes), max(mes), by = "month"), fill = list(n = 0)) %>%
    ungroup()
}

datos_ts    <- preparar_ts(datos)
datos_ts_m6 <- preparar_ts(datos %>% filter(transMw >= 6))

graficar_lineas_ts <- function(df, titulo) {
  ggplot(df, aes(x = mes, y = n, colour = Pais)) +
    geom_line(linewidth = if (stringr::str_detect(titulo, "Mw ≥ 6")) 1.2 else 1.1) +
    scale_colour_manual(values = paleta_pais) +
    labs(title = titulo, x = "Tiempo", y = "Número de sismos", colour = "País") +
    tema_base + theme(axis.text = element_text(size = 18), strip.text = element_text(size = 18, face = "bold"))
}

print(graficar_lineas_ts(datos_ts, "Frecuencia mensual de sismos"))
print(graficar_lineas_ts(datos_ts_m6, "Frecuencia mensual de sismos Mw ≥ 6"))

graficar_medias_anuales <- function(df, titulo) {
  df %>%
    mutate(Año = year(mes)) %>%
    group_by(Pais, Año) %>%
    summarise(Nivel = mean(n), .groups = "drop") %>%
    ggplot(aes(x = Año, y = Nivel, colour = Pais)) +
    geom_line(linewidth = 1.3) + geom_point(size = 2) +
    scale_colour_manual(values = paleta_pais) +
    labs(title = titulo, x = "Año", y = "Frecuencia mensual promedio", colour = "País") +
    tema_base + theme(axis.text = element_text(size = 18), strip.text = element_text(size = 18, face = "bold"))
}

print(graficar_medias_anuales(datos_ts, "Media de las frecuencias mensuales por año"))
print(graficar_medias_anuales(datos_ts_m6, "Media anual de las frecuencias mensuales Mw ≥ 6"))

# ================================================================================
# A.9 CURVAS DE LORENZ (concentración temporal de la actividad sísmica)
# ================================================================================

Lc_chile <- Lc((datos_ts %>% filter(Pais == "Chile"))$n)
Lc_japon <- Lc((datos_ts %>% filter(Pais == "Japón"))$n)

plot(Lc_chile, col = "#F8766D", lwd = 3, main = "Curvas de Lorenz de las frecuencias mensuales",
     xlab = "Proporción acumulada de meses", ylab = "Proporción acumulada de sismos",
     cex.main = 1.6, cex.lab = 1.4, cex.axis = 1.6)
lines(Lc_japon$p, Lc_japon$L, col = "#619CFF", lwd = 3)
abline(0, 1, lty = 2, lwd = 2)
legend("topleft", legend = c("Chile", "Japón"), col = paleta_pais, lwd = 3, bty = "n", cex = 1.3)

# ================================================================================
# A.10 TIEMPOS INTER-EVENTOS (descriptivo, catálogo CRUDO, sin declustering)
# ================================================================================
# Nota: este es el análisis exploratorio de la Asesoría 1. El análisis formal
# de tiempos entre eventos con el catálogo YA declusterizado está en la
# Parte B (Secciones B.20 y B.21) — son dos cosas distintas a propósito: acá
# se mezclan sismos generadores y réplicas, allá no.

inter_eventos <- datos %>%
  filter(Mw_cat %in% c("Strong", "Major", "Great")) %>%
  arrange(Pais, Mw_cat, time) %>%
  group_by(Pais, Mw_cat) %>%
  mutate(Tiempo = as.numeric(difftime(time, lag(time), units = "days"))) %>%
  filter(!is.na(Tiempo)) %>%
  ungroup()

tabla_inter <- inter_eventos %>%
  group_by(Pais, Mw_cat) %>%
  summarise(
    n = n(), Media = mean(Tiempo), DE = sd(Tiempo), Min = min(Tiempo),
    Q1 = quantile(Tiempo, .25), Mediana = median(Tiempo), Q3 = quantile(Tiempo, .75), Max = max(Tiempo),
    .groups = "drop"
  )

print(tabla_inter)

# ================================================================================
# A.11 ANÁLISIS PRELIMINAR POR SISTEMA DE SUBDUCCIÓN (Sección 5.5 del informe)
# ================================================================================

# --- A.11.1 Etiqueta de visualización para las fosas (corrige el typo "RYUKU") ---
datos <- datos %>%
  mutate(fosa_label = case_when(fosa == "RYUKU TRENCH" ~ "RYUKYU TRENCH", TRUE ~ fosa))

# --- A.11.2 Estadísticas descriptivas por fosa: transMw y depth ---
resumen_por_fosa <- function(data, variable, etiqueta) {
  data %>%
    filter(!is.na(fosa_label), !is.na(.data[[variable]])) %>%
    group_by(Pais, fosa_label) %>%
    summarise(
      Variable = etiqueta, n = n(), Media = round(mean(.data[[variable]]), 2),
      DE = round(sd(.data[[variable]]), 2), Min = round(min(.data[[variable]]), 2),
      Q25 = round(quantile(.data[[variable]], 0.25), 2), Mediana = round(median(.data[[variable]]), 2),
      Q75 = round(quantile(.data[[variable]], 0.75), 2), Max = round(max(.data[[variable]]), 2),
      .groups = "drop"
    ) %>%
    relocate(Variable, .after = fosa_label)
}

desc_transMw_fosa <- resumen_por_fosa(datos, "transMw", "transMw")
desc_depth_fosa   <- resumen_por_fosa(datos, "depth",   "depth")
tabla_descriptiva_fosa <- bind_rows(desc_transMw_fosa, desc_depth_fosa) %>% arrange(Pais, fosa_label, Variable)
print(tabla_descriptiva_fosa)

# --- A.11.3 Tablas de frecuencia por fosa: status, depth_cat, Mw_cat ---
tabla_categorica_por_fosa <- function(data, variable) {
  data %>%
    filter(!is.na(fosa_label), !is.na(.data[[variable]])) %>%
    group_by(Pais, fosa_label, across(all_of(variable))) %>%
    summarise(Frecuencia = n(), .groups = "drop_last") %>%
    mutate(Porcentaje = round(100 * Frecuencia / sum(Frecuencia), 2)) %>%
    ungroup()
}

tabla_status_fosa    <- tabla_categorica_por_fosa(datos, "status")
tabla_depth_cat_fosa <- tabla_categorica_por_fosa(datos, "depth_cat")
tabla_mw_cat_fosa    <- tabla_categorica_por_fosa(datos, "Mw_cat")
print(tabla_status_fosa); print(tabla_depth_cat_fosa); print(tabla_mw_cat_fosa)

# --- A.11.4 Ridgeline plots: magnitud y profundidad por fosa ---
print(
  ggplot(datos %>% filter(!is.na(fosa_label)), aes(x = transMw, y = fosa_label, fill = fosa_label)) +
    geom_density_ridges(scale = 1.5, alpha = 0.85, colour = "black", linewidth = 0.3) +
    scale_fill_viridis_d(option = "rocket", direction = -1, guide = "none") +
    labs(title = "Distribución de la magnitud de momento por fosa", x = expression(M[w]), y = NULL) +
    theme_minimal() +
    theme(plot.title = element_text(size = 18, face = "bold", hjust = 0.5),
          axis.title = element_text(size = 14, face = "bold"), axis.text = element_text(size = 12),
          panel.grid.minor = element_blank())
)

# Se marcan los cortes de 70 km y 300 km (los mismos que definen depth_cat)
# directamente en el gráfico, para que se vea a simple vista dónde cae cada fosa.
print(
  ggplot(datos %>% filter(!is.na(fosa_label)), aes(x = depth, y = fosa_label, fill = fosa_label)) +
    geom_density_ridges(scale = 1.5, alpha = 0.85, colour = "black", linewidth = 0.3) +
    geom_vline(xintercept = c(70, 300), linetype = "solid", colour = "#8B0000", linewidth = 1.2) +
    annotate("text", x = 70,  y = Inf, label = "70 km",  vjust = -0.6, hjust = -0.15, size = 5, fontface = "bold", colour = "#8B0000") +
    annotate("text", x = 300, y = Inf, label = "300 km", vjust = -0.6, hjust = -0.15, size = 5, fontface = "bold", colour = "#8B0000") +
    coord_cartesian(clip = "off") +
    scale_fill_viridis_d(option = "rocket", direction = -1, guide = "none") +
    labs(title = "Distribución de la profundidad por fosa", x = "Profundidad (km)", y = NULL) +
    theme_minimal() +
    theme(plot.title = element_text(size = 18, face = "bold", hjust = 0.5),
          axis.title = element_text(size = 14, face = "bold"), axis.text = element_text(size = 12),
          panel.grid.minor = element_blank(), plot.margin = margin(t = 30, r = 15, b = 10, l = 10))
)

# ================================================================================
# A.12 ASOCIACIÓN ENTRE depth_cat Y Mw_cat, POR PAÍS
# ================================================================================
# (Se evalúa a nivel de país, no de fosa: en Chile, fosa y país están casi
# confundidos, y no hay un mecanismo sismológico claro para desagregar la
# asociación magnitud-profundidad fosa por fosa.)

tabla_contingencia_pais_larga <- datos %>%
  filter(!is.na(depth_cat), !is.na(Mw_cat)) %>%
  count(Pais, depth_cat, Mw_cat, name = "Frecuencia")
print(tabla_contingencia_pais_larga)

generar_tabla_contingencia_pais <- function(data, pais_nombre) {
  data %>%
    filter(Pais == pais_nombre, !is.na(depth_cat), !is.na(Mw_cat)) %>%
    count(depth_cat, Mw_cat) %>%
    pivot_wider(names_from = Mw_cat, values_from = n, values_fill = 0)
}

tabla_contingencia_chile <- generar_tabla_contingencia_pais(datos, "Chile")
tabla_contingencia_japon <- generar_tabla_contingencia_pais(datos, "Japón")
cat("\n=== Tabla de contingencia: Chile ===\n"); print(tabla_contingencia_chile)
cat("\n=== Tabla de contingencia: Japón ===\n"); print(tabla_contingencia_japon)

# Correlación de Spearman entre las versiones ordinales de Mw_cat y depth_cat
datos <- datos %>%
  mutate(
    depth_cat_rango = case_when(depth_cat == "Poco profunda" ~ 1, depth_cat == "Intermedia" ~ 2,
                                 depth_cat == "Profunda" ~ 3, TRUE ~ NA_real_),
    Mw_cat_rango = case_when(Mw_cat == "Moderate" ~ 1, Mw_cat == "Strong" ~ 2,
                              Mw_cat == "Major" ~ 3, Mw_cat == "Great" ~ 4, TRUE ~ NA_real_)
  )

spearman_seguro <- function(x, y) {
  ok <- complete.cases(x, y)
  x <- x[ok]; y <- y[ok]
  if (length(x) < 3 || sd(x) == 0 || sd(y) == 0) return(c(rho = NA_real_, p_value = NA_real_))
  test <- suppressWarnings(cor.test(x, y, method = "spearman"))
  c(rho = round(unname(test$estimate), 3), p_value = signif(test$p.value, 4))
}

correlacion_mwcat_depthcat_por_pais <- datos %>%
  filter(!is.na(Pais)) %>%
  group_by(Pais) %>%
  group_modify(~ {
    res <- spearman_seguro(.x$Mw_cat_rango, .x$depth_cat_rango)
    data.frame(
      n = nrow(.x),
      n_cat_depth_presentes = length(unique(.x$depth_cat_rango[!is.na(.x$depth_cat_rango)])),
      n_cat_mw_presentes    = length(unique(.x$Mw_cat_rango[!is.na(.x$Mw_cat_rango)])),
      rho = res["rho"], p_value = res["p_value"]
    )
  }) %>%
  ungroup()

print(correlacion_mwcat_depthcat_por_pais)

# ================================================================================
# A.13 ASOCIACIÓN ENTRE dist_fosa_km Y depth, POR PAÍS
# ================================================================================

datos_dist_depth <- datos %>% filter(!is.na(dist_fosa_km), !is.na(depth))

print(
  ggplot(datos_dist_depth, aes(x = dist_fosa_km, y = depth)) +
    geom_point(alpha = 0.35, size = 1.3, colour = "grey30") +
    geom_smooth(aes(colour = "Pearson"), method = "lm", se = FALSE, linewidth = 1.3, linetype = "dashed") +
    geom_smooth(aes(colour = "Spearman"), method = "loess", se = FALSE, linewidth = 1.3) +
    scale_colour_manual(name = NULL, values = c("Pearson" = "#2874A6", "Spearman" = "#E74C3C")) +
    facet_wrap(~Pais, scales = "free") +
    labs(title = "Distancia a la fosa vs profundidad, por país", x = "Distancia a la fosa (km)", y = "Profundidad (km)") +
    tema_base + theme(legend.position = "bottom", legend.text = element_text(size = 14))
)

calcular_correlaciones_dist_depth <- function(data, pais_nombre) {
  sub <- data %>% filter(Pais == pais_nombre)
  data.frame(Pais = pais_nombre, n = nrow(sub),
             Pearson = round(cor(sub$dist_fosa_km, sub$depth, method = "pearson"), 3),
             Spearman = round(cor(sub$dist_fosa_km, sub$depth, method = "spearman"), 3))
}

correlacion_dist_depth_por_pais <- bind_rows(
  calcular_correlaciones_dist_depth(datos_dist_depth, "Chile"),
  calcular_correlaciones_dist_depth(datos_dist_depth, "Japón")
)
print(correlacion_dist_depth_por_pais)

# ================================================================================
# A.14 ASOCIACIÓN ENTRE transMw Y depth (VARIABLES CONTINUAS), POR PAÍS
# ================================================================================

datos_mw_depth <- datos %>% filter(!is.na(transMw), !is.na(depth))

print(
  ggplot(datos_mw_depth, aes(x = depth, y = transMw)) +
    geom_point(alpha = 0.35, size = 1.3, colour = "grey30") +
    geom_smooth(aes(colour = "Pearson"), method = "lm", se = FALSE, linewidth = 1.3, linetype = "dashed") +
    geom_smooth(aes(colour = "Spearman"), method = "loess", se = FALSE, linewidth = 1.3) +
    scale_colour_manual(name = NULL, values = c("Pearson" = "#2874A6", "Spearman" = "#E74C3C")) +
    facet_wrap(~Pais, scales = "free") +
    labs(title = "Profundidad vs magnitud de momento, por país", x = "Profundidad (km)", y = expression(M[w])) +
    tema_base + theme(legend.position = "bottom", legend.text = element_text(size = 14))
)

calcular_correlaciones_mw_depth <- function(data, pais_nombre) {
  sub <- data %>% filter(Pais == pais_nombre)
  data.frame(Pais = pais_nombre, n = nrow(sub),
             Pearson = round(cor(sub$depth, sub$transMw, method = "pearson"), 3),
             Spearman = round(cor(sub$depth, sub$transMw, method = "spearman"), 3))
}

correlacion_mw_depth_por_pais <- bind_rows(
  calcular_correlaciones_mw_depth(datos_mw_depth, "Chile"),
  calcular_correlaciones_mw_depth(datos_mw_depth, "Japón")
)
print(correlacion_mw_depth_por_pais)

# FIN PARTE A ====================================================================


# ################################################################################
# PARTE B — ASESORÍA II: DECLUSTERING (ZALIAPIN & BEN-ZION, 2020) E INFERENCIA
#           (Sección 6 del informe)
# ################################################################################
#
# Aplica el algoritmo de 4 pasos del paper (proximidad vecino-más-cercano,
# umbral eta0, reshuffling/normalización a alpha, thinning probabilístico) a
# Chile y Japón por separado, usando los mismos parámetros d y w para ambos
# países, un eta0 estimado automáticamente por país (mezcla de 2 gaussianas)
# y alpha0 = 0 para ambos (decisión final documentada en la Sección B.14).
#
# A diferencia de la Parte A, acá se carga el catálogo EXTENDIDO 1990-2025
# (no solo 2000-2025): los 10 años adicionales ("colchón") se usan como
# candidatos a padre real para los eventos de inicio de los 2000, pero se
# descartan de todas las salidas finales (tablas, gráficos, tests) vía la
# columna es_analisis. Esto es intencional, no una inconsistencia con la
# Parte A — ver comentario en B.1.


# ================================================================================
# B.1 CARGA Y PREPROCESAMIENTO (misma lógica de limpieza que A.3, aplicada
#     al catálogo extendido 1990-2025)
# ================================================================================

cargar_pais <- function(path_csv, pais, anio_inicio_analisis = 2000) {
  raw <- read_csv(path_csv, show_col_types = FALSE) %>% mutate(Pais = pais)
  filtrado <- raw %>%
    filter(
      if (pais == "Chile") str_detect(place, "Chile") & !str_detect(place, "Argentina")
      else str_detect(place, "Japan"),
      !(magType %in% c("m", "ml"))
    ) %>%
    mutate(
      # Idéntico a A.3, para que este catálogo se pueda cruzar directamente
      # con las tablas/gráficos de la Parte A sin rehacer la limpieza.
      transMw = case_when(
        magType %in% c("mw", "mwb", "mwc", "mwr", "mww") ~ mag,
        magType == "ms" & mag >= 3.0 & mag <= 6.1 ~ 0.67 * mag + 2.07,
        magType == "ms" & mag >= 6.2 & mag <= 8.2 ~ 0.99 * mag + 0.08,
        magType == "mb" & mag >= 3.5 & mag <= 6.7 ~ 0.85 * mag + 1.03,
        TRUE ~ NA_real_
      ),
      depth_cat = case_when(
        depth < 70 ~ "Poco profunda", depth >= 70 & depth < 300 ~ "Intermedia",
        depth >= 300 & depth <= 700 ~ "Profunda", TRUE ~ NA_character_
      ),
      Mw_cat = factor(case_when(
        transMw >= 3 & transMw < 4 ~ "Minor", transMw >= 4 & transMw < 5 ~ "Light",
        transMw >= 5 & transMw < 6 ~ "Moderate", transMw >= 6 & transMw < 7 ~ "Strong",
        transMw >= 7 & transMw < 8 ~ "Major", transMw >= 8 ~ "Great", TRUE ~ NA_character_
      ), levels = c("Minor", "Light", "Moderate", "Strong", "Major", "Great")),
      year = year(time)
    ) %>%
    filter(!is.na(transMw), !is.na(depth), !is.na(latitude), !is.na(longitude)) %>%
    arrange(time) %>%
    mutate(
      t_dias = as.numeric(difftime(time, min(time), units = "days")),
      idx = row_number(),
      # TRUE = evento del período de estudio (2000-2025); FALSE = evento del
      # "colchón" pre-2000, que solo sirve para dar candidatos a padre reales
      # a los eventos de inicio de siglo. El colchón se descarta de todas las
      # salidas finales (ver solo_analisis(), más abajo).
      es_analisis = year >= anio_inicio_analisis
    )
  filtrado
}

# ================================================================================
# B.2 DISTANCIA HIPOCENTRAL 3D (km): haversine horizontal + diferencia de profundidad
# ================================================================================

dist_hipocentral_km <- function(lat1, lon1, dep1, lat2, lon2, dep2) {
  R <- 6371
  lat1r <- lat1 * pi / 180; lon1r <- lon1 * pi / 180
  lat2r <- lat2 * pi / 180; lon2r <- lon2 * pi / 180
  dlat <- lat2r - lat1r; dlon <- lon2r - lon1r
  a <- sin(dlat / 2)^2 + cos(lat1r) * cos(lat2r) * sin(dlon / 2)^2
  a <- pmin(pmax(a, 0), 1)
  horiz <- 2 * R * asin(sqrt(a))
  vert <- dep1 - dep2
  sqrt(horiz^2 + vert^2)
}

# ================================================================================
# B.3 PROXIMIDAD VECINO-MÁS-CERCANO (Ec. 1 y 3 del paper) Y PADRE
#     eta_ij = t_ij * (r_ij)^d * 10^(-w*m_i),  con t_ij > 0
#     eta_j  = min_i(eta_ij), i anterior a j  ->  padre de j
# ================================================================================

calcular_eta_padre <- function(datos_pais, d = 2.5, w = 0) {
  n <- nrow(datos_pais)
  t <- datos_pais$t_dias; lat <- datos_pais$latitude; lon <- datos_pais$longitude
  dep <- datos_pais$depth; mag <- datos_pais$transMw
  eta <- rep(Inf, n)
  padre_idx <- rep(NA_integer_, n)
  for (j in 2:n) {
    i_idx <- 1:(j - 1)
    tij <- t[j] - t[i_idx]
    rij <- dist_hipocentral_km(lat[j], lon[j], dep[j], lat[i_idx], lon[i_idx], dep[i_idx])
    rij <- pmax(rij, 1e-6)
    eij <- tij * (rij^d) * 10^(-w * mag[i_idx])
    k <- which.min(eij)
    eta[j] <- eij[k]
    padre_idx[j] <- i_idx[k]
  }
  list(eta = eta, padre_idx = padre_idx)
}

# ================================================================================
# B.4 UMBRAL CRUDO eta0 AUTOMÁTICO
#     (bimodalidad de log10(eta) vía mezcla de 2 gaussianas — Sección 4.2 del
#     paper, recomendado cuando el valor genérico de la literatura no aplica
#     directamente a esta parametrización)
# ================================================================================

ajustar_gmm_eta <- function(eta) {
  x <- log10(eta[is.finite(eta)])
  mod <- Mclust(x, G = 2, verbose = FALSE)
  medias <- mod$parameters$mean
  orden <- order(medias)
  lo <- medias[orden[1]]; hi <- medias[orden[2]]
  grilla <- seq(lo, hi, length.out = 4000)
  dens <- predict(mod, grilla)$z
  col_lo <- orden[1]
  diffs <- dens[, col_lo] - 0.5
  cambios <- which(diff(sign(diffs)) != 0)
  cruce <- if (length(cambios) > 0) grilla[cambios[1]] else mean(c(lo, hi))
  list(modelo = mod, x = x, log10_eta0 = cruce, eta0 = 10^cruce)
}

auto_eta0 <- function(eta) ajustar_gmm_eta(eta)$eta0

# ================================================================================
# B.5 RESHUFFLING (Ec. 6) + NORMALIZACIÓN (Ec. 7): alpha_i
# ================================================================================

calcular_alpha <- function(datos_pais, eta, eta0, d = 2.5, M = 60) {
  n <- nrow(datos_pais)
  t <- datos_pais$t_dias; lat <- datos_pais$latitude; lon <- datos_pais$longitude; dep <- datos_pais$depth
  idx_cand <- which(eta > eta0)
  n0 <- length(idx_cand)
  lat_c <- lat[idx_cand]; lon_c <- lon[idx_cand]; dep_c <- dep[idx_cand]
  suma_log_kappa <- rep(0, n); cuenta_log_kappa <- rep(0, n)
  tmin <- min(t); tmax <- max(t)

  # CORRECCIÓN (encontrada leyendo la Sec. 4.2 del paper): si el propio
  # evento i es uno de los candidatos usados para construir los catálogos
  # reshuffleados (Ec. 6), el catálogo reshuffleado contiene un punto
  # EXACTAMENTE en la posición espacial de i (con tiempo reasignado al azar).
  # Sin excluir esa auto-comparación, r_ij=0 fuerza kappa=0 cada vez que el
  # tiempo reasignado cae antes de t[i] (~mitad de las veces), lo que infla
  # alpha=eta/kappa de forma masiva y artificial. Validado con un catálogo
  # sintético de Poisson puro (sin clustering): SIN la corrección,
  # log10(alpha) salía con mediana ~9 (debería ser ~0 según la Ec. 10 del
  # paper); CON la corrección, mediana ~0.07 y percentiles [-1.7, 1.0],
  # calzando con el rango que el paper recomienda explorar (-1 a 1).
  pos_en_cand <- rep(NA_integer_, n)
  pos_en_cand[idx_cand] <- seq_along(idx_cand)

  for (k in 1:M) {
    u <- runif(n0, tmin, tmax)
    for (i in 1:n) {
      valid <- u < t[i]
      p_self <- pos_en_cand[i]
      if (!is.na(p_self)) valid[p_self] <- FALSE  # excluir auto-comparación
      if (!any(valid)) next
      rij <- dist_hipocentral_km(lat[i], lon[i], dep[i], lat_c[valid], lon_c[valid], dep_c[valid])
      rij <- pmax(rij, 1e-6)
      tij <- t[i] - u[valid]
      kap <- min(tij * (rij^d))
      suma_log_kappa[i] <- suma_log_kappa[i] + log10(kap)
      cuenta_log_kappa[i] <- cuenta_log_kappa[i] + 1
    }
  }

  media_log_kappa <- ifelse(cuenta_log_kappa > 0, suma_log_kappa / pmax(cuenta_log_kappa, 1), NA_real_)
  log10_eta <- log10(eta)
  log10_alpha <- ifelse(is.na(media_log_kappa), log10_eta, log10_eta - media_log_kappa)
  list(log10_alpha = log10_alpha, n0 = n0)
}

# ================================================================================
# B.6 THINNING (Ec. 8-9) Y ETIQUETADO GENERADOR / RÉPLICA
#
#     *** PUNTO CRÍTICO DE REPRODUCIBILIDAD ***
#     Esta función usa DOS fuentes de aleatoriedad: el reshuffling dentro de
#     calcular_alpha() (llamada más abajo) y el thinning final U <- runif(n)
#     de la línea siguiente. NO se fija una semilla acá adentro, y TAMPOCO se
#     fija una semilla nueva justo antes de llamarla para la corrida de
#     producción (Sección B.8): esa función se llama varias veces a lo largo
#     del script con fines distintos (exploración de alpha0, corrida de
#     producción, batería de Fase 0), y todas comparten una única semilla
#     global fijada una sola vez al principio del script (Sección 1.2). El
#     resultado de cada llamada depende de cuánta aleatoriedad ya se consumió
#     en llamadas anteriores — así es exactamente como se generaron los
#     números que están en el informe entregado, así que se preserva ese
#     mismo orden acá. Reiniciar la semilla justo antes de esta función
#     (como hacía una versión anterior de este script) cambiaría el
#     resultado: ver advertencia en la Sección B.8.
# ================================================================================

declustering_zbz <- function(datos_pais, d = 2.5, w = 0, M = 60, alpha0 = 0, eta0 = NULL) {
  n <- nrow(datos_pais)
  ep <- calcular_eta_padre(datos_pais, d = d, w = w)
  eta <- ep$eta; padre_idx <- ep$padre_idx
  if (is.null(eta0)) eta0 <- auto_eta0(eta)
  al <- calcular_alpha(datos_pais, eta, eta0, d = d, M = M)
  log10_alpha <- al$log10_alpha
  alpha <- 10^log10_alpha
  A0 <- 10^alpha0
  U <- runif(n)                                   # thinning probabilístico final
  P_back <- pmin(alpha * A0, 1)
  es_fondo <- (alpha * A0) > U
  es_fondo[1] <- TRUE  # el primer evento del catálogo es raíz por construcción (eta=Inf)

  # Traza la cadena de padres de cada evento hasta llegar a su generador
  # (la raíz de fondo de su familia/clúster)
  generador_idx <- integer(n)
  for (i in 1:n) {
    cur <- i
    visitados <- c()
    while (!es_fondo[cur] && !(cur %in% visitados)) {
      visitados <- c(visitados, cur)
      p <- padre_idx[cur]
      if (is.na(p)) break
      cur <- p
    }
    generador_idx[i] <- cur
  }

  out <- datos_pais %>%
    mutate(
      eta = eta, log10_alpha = log10_alpha, P_back = P_back, es_fondo = es_fondo,
      tipo_evento = if_else(es_fondo, "Generador/Fondo", "Réplica"),
      id_padre = if_else(is.na(padre_idx), NA_character_, id[padre_idx]),
      id_generador = id[generador_idx]
    )
  attr(out, "eta0_usado") <- eta0
  attr(out, "alpha0_usado") <- alpha0
  attr(out, "pct_fondo") <- mean(es_fondo) * 100
  out
}

# ================================================================================
# B.7 TESTS DE FASE 0 (Sección 5 del paper): KS, Bridge, Luen-Stark
#     (se definen ANTES de aplicarse a Chile/Japón, a diferencia del script
#     original donde aparecían más abajo — acá se necesitan disponibles desde
#     la exploración de alpha0 en adelante)
# ================================================================================

ks_estacionariedad_pvalue <- function(t) {
  n <- length(t)
  if (n < 5) return(NA_real_)
  tmin <- min(t); tmax <- max(t)
  if (tmax <= tmin) return(NA_real_)
  u <- (t - tmin) / (tmax - tmin)
  ks.test(u, "punif")$p.value
}

bridge_stat <- function(t_sorted, T) {
  n <- length(t_sorted)
  if (n < 3) return(0)
  m <- 2:(n - 1)
  tau <- t_sorted[m]
  var_m <- n * tau * (T - tau) / T^2
  sd_m <- sqrt(var_m)
  b_before <- (m - 1) - n * tau / T
  b_after  <- m - n * tau / T
  max(max(abs(b_after / sd_m)), max(abs(b_before / sd_m)))
}

bridge_pvalue <- function(t, M = 2000, seed = 0) {
  n <- length(t)
  if (n < 5) return(NA_real_)
  set.seed(seed)   # semilla propia, por realización -> ya era reproducible en el original
  tmin <- min(t); tmax <- max(t)
  T <- tmax - tmin
  if (T <= 0) return(NA_real_)
  t_rel <- sort(t - tmin)
  obs <- bridge_stat(t_rel, T)
  sim_stats <- numeric(M)
  for (b in 1:M) {
    s <- sort(runif(n, 0, 1))
    s <- (s - s[1]) / (s[n] - s[1]) * T
    sim_stats[b] <- bridge_stat(s, T)
  }
  mean(sim_stats >= obs)
}

ls_stat_from_dom <- function(x_dom, t) {
  n <- length(t)
  t_mat <- outer(t, t, function(ti, tj) tj <= ti)
  Ft  <- rowMeans(t_mat)
  Fx  <- rowMeans(x_dom)
  Fxt <- rowMeans(x_dom & t_mat)
  max(abs(Fxt - Fx * Ft))
}

luen_stark_pvalue <- function(lon, lat, t, M = 100, seed = 0) {
  n <- length(t)
  if (n < 10) return(NA_real_)
  set.seed(seed)   # semilla propia, por realización
  lon_dom <- outer(lon, lon, function(a, b) b <= a)
  lat_dom <- outer(lat, lat, function(a, b) b <= a)
  x_dom <- lon_dom & lat_dom
  obs <- ls_stat_from_dom(x_dom, t)
  perm_stats <- numeric(M)
  for (k in 1:M) perm_stats[k] <- ls_stat_from_dom(x_dom, sample(t))
  mean(perm_stats >= obs)
}

# ================================================================================
# B.8 APLICACIÓN A CHILE Y JAPÓN
#
#    ALPHA0 FINAL (decidido con calcular_alpha() ya corregido y la grilla de
#    la Sección B.16 en el rango correcto [-3,3]):
#      Chile: alpha0 = 0. Bridge media=0.783 IC=[0.752,0.814]; KS
#             media=0.497 IC=[0.439,0.555]; Luen-Stark media=0.893
#             IC=[0.856,0.930] — los tres pasan con margen amplio. En
#             alpha0=0.5 KS ya rechaza (media=0.042, IC todo bajo 0.05),
#             confirmando que 0 es el borde superior real. % fondo = 33.4%.
#      Japón: alpha0 = 0 (por simetría con Chile). KS pasa en promedio
#             (media=0.100) pero con margen más frágil: sd=0.097 sobre 50
#             realizaciones implica que ~30% de realizaciones individuales de
#             KS caerían bajo 0.05 (contra <1% en alpha0=-0.5). Se documenta
#             como limitación conocida, no como motivo de descarte: el
#             criterio decisivo es Luen-Stark, que en 0 pasa con margen
#             amplio. Ver Sección B.16 para el detalle completo.
# ================================================================================

chile_raw <- cargar_pais(RUTA_CHILE_90_25, "Chile")
japon_raw <- cargar_pais(RUTA_JAPON_90_25, "Japón")

cat("N Chile total (1990-2025, post-limpieza):", nrow(chile_raw),
    " | colchón pre-2000:", sum(!chile_raw$es_analisis),
    " | período de estudio 2000-2025:", sum(chile_raw$es_analisis), "\n")
cat("N Japón total (1990-2025, post-limpieza):", nrow(japon_raw),
    " | colchón pre-2000:", sum(!japon_raw$es_analisis),
    " | período de estudio 2000-2025:", sum(japon_raw$es_analisis), "\n")

# Se queda solo con las filas del período de estudio, para reportes/tablas/gráficos
solo_analisis <- function(datos_decl) datos_decl %>% dplyr::filter(es_analisis)

# --- Paso previo recomendado: explorar alpha0 antes de fijarlo (Fase 0, exploratorio) ---
explorar_alpha0 <- function(datos_pais, d = 2.5, w = 0, M = 60, alphas = c(-1, -0.6, -0.3, 0, 0.3)) {
  ep <- calcular_eta_padre(datos_pais, d = d, w = w)
  eta0 <- auto_eta0(ep$eta)
  al <- calcular_alpha(datos_pais, ep$eta, eta0, d = d, M = M)
  alpha <- 10^al$log10_alpha
  U <- runif(length(alpha))
  es_analisis <- datos_pais$es_analisis
  resultados <- sapply(alphas, function(a0) {
    A0 <- 10^a0
    es_fondo <- (alpha * A0) > U | seq_along(alpha) == 1
    c(pct_fondo_total = mean(es_fondo) * 100, pct_fondo_analisis = mean(es_fondo[es_analisis]) * 100)
  })
  data.frame(alpha0 = alphas, t(resultados), eta0_usado = eta0)
}

cat("\n--- Exploración de alpha0 (Chile, incluye colchón 1990-1999 en el cálculo) ---\n")
print(explorar_alpha0(chile_raw))
cat("\n--- Exploración de alpha0 (Japón, incluye colchón 1990-1999 en el cálculo) ---\n")
print(explorar_alpha0(japon_raw))

# --- CORRIDA DE PRODUCCIÓN: la que efectivamente genera el catálogo declusterizado
#     que se usa en el resto del informe (Cuadros y Figuras de la Sección 6). ---
#
# declustering_zbz() corre sobre chile_raw/japon_raw COMPLETOS (1990-2025),
# para que los eventos de 2000-2010 tengan candidatos a padre reales del
# colchón; se filtran recién después con solo_analisis().
#
# *** NO se reinicia la semilla acá. *** A propósito: esta corrida continúa
# la misma secuencia aleatoria que ya viene consumiendo el script desde el
# set.seed(2026) único de la Sección 1.2 (pasando por las dos llamadas a
# explorar_alpha0() de arriba). Esa es exactamente la secuencia que generó
# el catálogo declusterizado —y por lo tanto todos los Cuadros y Figuras de
# la Sección 6— que ya está en el informe entregado.
#
# ADVERTENCIA (motivo de un error real detectado 2026-07-12): una versión
# anterior de este script agregaba acá un set.seed() nuevo, pensando que
# reforzaba la reproducibilidad. Es un error tentador porque SÍ hace que el
# script sea reproducible... pero reproduce una realización aleatoria
# DISTINTA a la que generó los números ya publicados en el informe (porque
# reinicia el generador aleatorio en vez de continuar la secuencia natural),
# lo que producía diferencias importantes en todos los resultados de la
# Sección 6 al comparar contra el informe. La reproducibilidad de este
# script depende SOLO del set.seed(2026) inicial (Sección 1.2) + correr el
# archivo completo y sin reordenar, no de reinicios adicionales acá.
#
# MODO_REPRODUCCION_INFORME (Sección 1.1.1): si está en TRUE, en vez de
# sortear el declustering de nuevo, se cargan los catálogos congelados que
# el propio script exportó la vez que generó el informe -evitando por
# completo el problema de que cualquier sorteo aleatorio extra o faltante
# antes de este punto cambie el resultado. Es la forma robusta de
# reproducir el informe ya entregado.
if (MODO_REPRODUCCION_INFORME) {

  cat("\n*** MODO_REPRODUCCION_INFORME = TRUE: se omite declustering_zbz() y se cargan los catálogos ya declusterizados ***\n")
  cat("Archivos esperados (deben estar en RUTA_DATOS, junto a los CSV crudos):\n")
  cat(" -", RUTA_CHILE_DECL_COLCHON, "\n")
  cat(" -", RUTA_JAPON_DECL_COLCHON, "\n")

  if (!file.exists(RUTA_CHILE_DECL_COLCHON) || !file.exists(RUTA_JAPON_DECL_COLCHON)) {
    stop(
      "MODO_REPRODUCCION_INFORME = TRUE pero falta al menos uno de los catálogos ",
      "congelados de arriba. Verifica que ambos archivos estén dentro de la carpeta ",
      "data/, o pon MODO_REPRODUCCION_INFORME <- FALSE (Sección 1.1.1) para correr ",
      "el declustering desde cero en vez de cargarlo."
    )
  }

  # col_types explícito: id/id_padre/id_generador se fuerzan a character
  # porque son códigos alfanuméricos (ej. "usp000h5fb"), no números; y
  # es_analisis/es_fondo a lógico (readr los adivina bien solo si ve
  # literalmente "TRUE"/"FALSE" en la columna, que es como los escribió
  # write_csv(), pero se fuerza el tipo igual para evitar sorpresas).
  col_tipos_decl <- readr::cols(
    id           = readr::col_character(),
    id_padre     = readr::col_character(),
    id_generador = readr::col_character(),
    es_analisis  = readr::col_logical(),
    es_fondo     = readr::col_logical(),
    .default     = readr::col_guess()
  )

  chile_decl <- read_csv(RUTA_CHILE_DECL_COLCHON, col_types = col_tipos_decl)
  japon_decl <- read_csv(RUTA_JAPON_DECL_COLCHON, col_types = col_tipos_decl)

  # declustering_zbz() (Sección B.6) guarda eta0/alpha0/pct_fondo como
  # attr() del data frame -esto NO viaja en el CSV (write_csv no exporta
  # atributos), así que se reconstruyen acá. pct_fondo se recalcula exacto
  # desde los propios datos cargados (es determinístico); eta0_usado y
  # alpha0_usado son solo informativos para el cat() de más abajo -alpha0
  # se deja en el valor ya documentado arriba en el encabezado de la
  # Sección B.8 (alpha0 = 0 para ambos países) en vez de NA.
  attr(chile_decl, "eta0_usado")   <- NA_real_  # no se guarda en el CSV
  attr(chile_decl, "alpha0_usado") <- 0
  attr(chile_decl, "pct_fondo")    <- mean(chile_decl$es_fondo) * 100
  attr(japon_decl, "eta0_usado")   <- NA_real_
  attr(japon_decl, "alpha0_usado") <- 0
  attr(japon_decl, "pct_fondo")    <- mean(japon_decl$es_fondo) * 100

} else {

  chile_decl <- declustering_zbz(chile_raw, d = 2.5, w = 0, M = 100, alpha0 = 0)
  japon_decl <- declustering_zbz(japon_raw, d = 2.5, w = 0, M = 100, alpha0 = 0)

}

# ================================================================================
# B.8.1 REASIGNACIÓN DEL "GENERADOR" DE CADA FAMILIA: MAYOR MAGNITUD, NO RAÍZ TEMPORAL
#
#    *** ESTE BLOQUE FALTABA EN LA VERSIÓN ANTERIOR DE ESTE SCRIPT — ES LA
#        CORRECCIÓN QUE PEDISTE (2026-07-12): sin esto, "generador" queda
#        igual a lo que ya calcula declustering_zbz() (Sección B.6): la RAÍZ
#        TEMPORAL/ALGORÍTMICA del árbol de padres de cada familia, es decir,
#        el primer ancestro que el algoritmo encontró clasificado como
#        fondo al recorrer la cadena de padres hacia atrás — NO
#        necesariamente el sismo más fuerte de esa familia. ***
#
#    Con w=0 (búsqueda de vecino-más-cercano ciega a la magnitud, tal como
#    recomienda el paper), un precursor chico puede terminar como raíz
#    algorítmica de una familia que después encadena a un sismo mucho más
#    grande. El paper (Zaliapin & Ben-Zion 2020, Sección 4.1, párrafo
#    siguiente al Paso 4) reconoce explícitamente ambas convenciones como
#    válidas para definir "generador" ("one can decide to keep the largest
#    earthquake from every cluster... depends on the problem at hand"). acá
#    se usa la de MAYOR MAGNITUD: el generador de cada familia pasa a ser el
#    evento con mayor transMw dentro de esa familia completa (raíz + todas
#    sus réplicas), no la raíz.
#
#    Caso real que motivó esta decisión (Chile): la raíz algorítmica
#    usp000h5fb (M5.1, 2009-12-29) encadena, vía usp000h6du (M5.1,
#    2010-01-21, vecino más cercano verificado), con el terremoto del MAULE
#    2010 (M8.8). Sin esta reasignación, las ~440 réplicas de Maule 2010
#    quedan mal atribuidas a un evento M5.1 en toda la Sección 6.1.1/6.7 del
#    informe (top-10 generadores, correlación magnitud-productividad,
#    regresión logística, modelo Binomial Negativa).
#
#    IMPORTANTE: esto NO toca es_fondo/tipo_evento (la clasificación
#    fondo-vs-réplica del thinning de Zaliapin-Ben-Zion en sí, usada en el
#    resto de la Sección 6 — tasas, distribuciones, proporciones, etc. —
#    sigue siendo la que calcula el algoritmo, sin modificar). Solo cambia a
#    quién se le atribuyen las réplicas de una familia para el análisis de
#    productividad (Secciones B.9, B.17, B.18, B.27, B.28, B.31).
# ================================================================================

reasignar_generador_mayor_magnitud <- function(datos_decl) {
  # declustering_zbz() (Sección B.6) guarda eta0/alpha0/pct_fondo como
  # atributos del data frame (attr(out, "eta0_usado") <- ...). Las
  # transformaciones de dplyr de abajo (rename/group_by/mutate/ungroup) NO
  # preservan atributos "custom" como esos -- se guardan acá antes y se
  # restauran al final, para que los cat() de la Sección B.8 (que leen
  # attr(chile_decl, "eta0_usado") después de llamar a esta función) sigan
  # funcionando igual que antes de agregar este paso.
  eta0_usado   <- attr(datos_decl, "eta0_usado")
  alpha0_usado <- attr(datos_decl, "alpha0_usado")
  pct_fondo    <- attr(datos_decl, "pct_fondo")

  out <- datos_decl %>%
    dplyr::rename(id_familia = id_generador) %>%   # se conserva el id de la raíz temporal, renombrado, solo para trazabilidad
    dplyr::group_by(id_familia) %>%
    dplyr::mutate(id_generador = id[which.max(transMw)]) %>%
    dplyr::ungroup()

  attr(out, "eta0_usado")   <- eta0_usado
  attr(out, "alpha0_usado") <- alpha0_usado
  attr(out, "pct_fondo")    <- pct_fondo

  n_familias  <- length(unique(out$id_familia))
  n_cambiadas <- out %>% dplyr::distinct(id_familia, id_generador) %>% dplyr::filter(id_familia != id_generador) %>% nrow()
  cat(sprintf("Reasignación de generador: %d de %d familias cambiaron de raíz temporal a evento de mayor magnitud.\n",
              n_cambiadas, n_familias))

  # Chequeo de cordura: el evento de mayor magnitud de cada familia debería
  # ser casi siempre, por sí mismo, un evento de fondo (es_fondo==TRUE) —
  # un sismo tan grande normalmente tiene eta alto y el propio algoritmo ya
  # lo clasifica como fondo. Si no se cumple para algunas familias no es
  # necesariamente un error, pero vale la pena revisarlo manualmente.
  chequeo <- out %>%
    dplyr::filter(id == id_generador) %>%
    dplyr::summarise(n_generadores = dplyr::n(), n_generadores_no_fondo = sum(!es_fondo))
  if (chequeo$n_generadores_no_fondo > 0) {
    cat(sprintf(
      "Aviso: %d de %d generadores reasignados (mayor magnitud de su familia) NO están clasificados como es_fondo==TRUE por el thinning de ZBZ — revisar manualmente.\n",
      chequeo$n_generadores_no_fondo, chequeo$n_generadores
    ))
  }

  out
}

cat("\n--- Reasignando generador = evento de mayor magnitud por familia (no raíz temporal) ---\n")
chile_decl <- reasignar_generador_mayor_magnitud(chile_decl)
japon_decl <- reasignar_generador_mayor_magnitud(japon_decl)

chile_decl_analisis <- solo_analisis(chile_decl)
japon_decl_analisis <- solo_analisis(japon_decl)

cat("\nChile: eta0=", attr(chile_decl, "eta0_usado"), " alpha0=", attr(chile_decl, "alpha0_usado"),
    " -> % fondo (2000-2025) =", round(mean(chile_decl_analisis$es_fondo) * 100, 1), "\n")
cat("Japón: eta0=", attr(japon_decl, "eta0_usado"), " alpha0=", attr(japon_decl, "alpha0_usado"),
    " -> % fondo (2000-2025) =", round(mean(japon_decl_analisis$es_fondo) * 100, 1), "\n")

# ================================================================================
# B.9 TABLA DE PRODUCTIVIDAD POR GENERADOR
# ================================================================================

tabla_generadores <- function(datos_decl_analisis, datos_decl_completo) {
  datos_decl_analisis %>%
    dplyr::filter(tipo_evento == "Réplica") %>%
    dplyr::count(id_generador, name = "n_replicas") %>%
    dplyr::left_join(
      datos_decl_completo %>% dplyr::select(id, transMw, time, latitude, longitude, depth, es_analisis),
      by = c("id_generador" = "id")
    ) %>%
    dplyr::rename(generador_en_periodo_estudio = es_analisis) %>%
    dplyr::mutate(generador_en_buffer = !generador_en_periodo_estudio) %>%
    dplyr::arrange(desc(n_replicas))
}

gen_chile <- tabla_generadores(chile_decl_analisis, chile_decl)
gen_japon <- tabla_generadores(japon_decl_analisis, japon_decl)

cat("\nTop 5 generadores Chile:\n"); print(head(gen_chile, 5))
cat("\nTop 5 generadores Japón:\n"); print(head(gen_japon, 5))
cat(sprintf("\nRéplicas de 2000-2025 cuyo generador está en el colchón pre-2000 — Chile: %d | Japón: %d\n",
            sum(gen_chile$generador_en_buffer * gen_chile$n_replicas, na.rm = TRUE),
            sum(gen_japon$generador_en_buffer * gen_japon$n_replicas, na.rm = TRUE)))

# ================================================================================
# B.10 GUARDAR RESULTADOS (catálogos declusterizados y tablas de generadores)
# ================================================================================

write_csv(chile_decl_analisis, "chile_declusterizado.csv")
write_csv(japon_decl_analisis, "japon_declusterizado.csv")
write_csv(gen_chile, "chile_generadores.csv")
write_csv(gen_japon, "japon_generadores.csv")
write_csv(chile_decl, "chile_declusterizado_completo_con_colchon.csv")
write_csv(japon_decl, "japon_declusterizado_completo_con_colchon.csv")

# ================================================================================
# B.11 CHEQUEO DE CORDURA: secuencia de Tōhoku 2011 (M9.1)
# ================================================================================
# Verifica que el algoritmo clasifique correctamente como "Réplica" a los
# eventos cercanos en espacio y tiempo al terremoto de Tōhoku (2011-03-11).

tohoku <- japon_decl_analisis %>% filter(year(time) == 2011, month(time) == 3, transMw > 8.5)
if (nrow(tohoku) > 0) {
  t0 <- tohoku$time[1]
  ventana <- japon_decl_analisis %>% filter(time > t0, time <= t0 + days(30))
  d_km <- dist_hipocentral_km(tohoku$latitude[1], tohoku$longitude[1], tohoku$depth[1],
                               ventana$latitude, ventana$longitude, ventana$depth)
  cercanos <- ventana[d_km < 300, ]
  cat("\nChequeo Tōhoku 2011: clasificado como", tohoku$tipo_evento[1], "\n")
  cat("Eventos <300km y <=30 días después:", nrow(cercanos),
      "| clasificados como Réplica:", sum(cercanos$tipo_evento == "Réplica"),
      sprintf("(%.0f%%)\n", 100 * mean(cercanos$tipo_evento == "Réplica")))
}

# ================================================================================
# B.12 PREPARAR UNA VEZ POR PAÍS (eta, padre, eta0, alpha) — para las figuras
#      diagnósticas y la curva de sensibilidad
# ================================================================================

preparar_pais <- function(datos_pais, d = 2.5, w = 0, M = 70, seed = 1) {
  set.seed(seed)
  ep <- calcular_eta_padre(datos_pais, d = d, w = w)
  gmm <- ajustar_gmm_eta(ep$eta)
  al <- calcular_alpha(datos_pais, ep$eta, gmm$eta0, d = d, M = M)
  list(datos = datos_pais, eta = ep$eta, padre_idx = ep$padre_idx, eta0 = gmm$eta0, gmm = gmm, alpha = 10^al$log10_alpha)
}

prep_chile <- preparar_pais(chile_raw, seed = 1)
prep_japon <- preparar_pais(japon_raw, seed = 1)

cat("\n--- eta0 seleccionado por la mezcla de 2 gaussianas (usa 1990-2025 completo) ---\n")
cat(sprintf("Chile: eta0 = %.4f  (log10(eta0) = %.4f)\n", prep_chile$eta0, log10(prep_chile$eta0)))
cat(sprintf("Japón: eta0 = %.4f  (log10(eta0) = %.4f)\n", prep_japon$eta0, log10(prep_japon$eta0)))

subset_analisis <- function(prep) {
  idx <- which(prep$datos$es_analisis)
  list(datos = prep$datos[idx, ], alpha = prep$alpha[idx], eta0 = prep$eta0, gmm = prep$gmm)
}
prep_chile_analisis <- subset_analisis(prep_chile)
prep_japon_analisis <- subset_analisis(prep_japon)

# --- B.12.1 Gráfica de la mezcla de 2 gaussianas sobre log10(eta), por país ---
graficar_gmm_eta0 <- function(prep, pais) {
  x <- prep$gmm$x; mod <- prep$gmm$modelo
  medias <- mod$parameters$mean
  varz <- mod$parameters$variance$sigmasq
  if (length(varz) == 1) varz <- rep(varz, length(medias))
  sds <- sqrt(varz); pesos <- mod$parameters$pro
  orden <- order(medias)
  etiquetas <- c("Agrupados (η chico)", "Fondo (η grande)")
  xs <- seq(min(x), max(x), length.out = 600)
  dens_componentes <- bind_rows(lapply(seq_along(orden), function(k) {
    comp <- orden[k]
    data.frame(x = xs, densidad = pesos[comp] * dnorm(xs, mean = medias[comp], sd = sds[comp]), poblacion = etiquetas[k])
  }))
  dens_total <- data.frame(x = xs, densidad = pesos[1] * dnorm(xs, medias[1], sds[1]) + pesos[2] * dnorm(xs, medias[2], sds[2]))
  ggplot() +
    geom_histogram(data = data.frame(x = x), aes(x = x, y = after_stat(density)), bins = 60, fill = "grey85", color = "white", linewidth = 0.2) +
    geom_line(data = dens_componentes, aes(x = x, y = densidad, color = poblacion), linewidth = 1.1) +
    geom_line(data = dens_total, aes(x = x, y = densidad), color = "black", linewidth = 0.7, linetype = "dashed") +
    geom_vline(xintercept = prep$gmm$log10_eta0, color = "#eda100", linewidth = 1) +
    annotate("label", x = prep$gmm$log10_eta0, y = max(dens_total$densidad) * 0.95,
             label = sprintf("η₀ = %.3g\nlog₁₀(η₀) = %.3f", prep$eta0, prep$gmm$log10_eta0),
             color = "#0b0b0b", fill = "white", size = 3.4, label.size = 0, hjust = -0.05) +
    scale_color_manual(values = c("Agrupados (η chico)" = "#e34948", "Fondo (η grande)" = "#2a78d6")) +
    labs(title = paste0("Mezcla de 2 gaussianas sobre log₁₀(η) — ", pais),
         subtitle = "η₀ = cruce entre 'agrupados' y 'fondo' (estimado sobre 1990-2025, colchón incluido)",
         x = expression("log"[10] * "(" * eta[i] * ")"), y = "Densidad", color = "Población estimada (Mclust)") +
    tema_base_decl + theme(legend.position = "top")
}

grafico_gmm_chile <- graficar_gmm_eta0(prep_chile, "Chile")
grafico_gmm_japon <- graficar_gmm_eta0(prep_japon, "Japón")
print(grafico_gmm_chile); print(grafico_gmm_japon)
ggsave("gmm_eta0_Chile.png", grafico_gmm_chile, width = 8.5, height = 5.8, dpi = 200, bg = "white")
ggsave("gmm_eta0_Japon.png", grafico_gmm_japon, width = 8.5, height = 5.8, dpi = 200, bg = "white")

# ================================================================================
# B.13 CURVA DE SENSIBILIDAD: % de fondo esperado vs. alpha0
#      Rango [-3,3], que contiene con margen el rango [-1,1] que recomienda
#      la Sección 4.2 del paper (ver nota metodológica en B.14).
# ================================================================================

grilla_alpha0 <- seq(-3, 3, by = 0.05)
grilla_alpha0_gruesa <- seq(-3, 3, by = 0.5)

curva_sensibilidad <- function(prep, pais, grilla = grilla_alpha0) {
  props <- sapply(grilla, function(a0) {
    A0 <- 10^a0
    mean(pmin(prep$alpha * A0, 1)) * 100
  })
  data.frame(Pais = pais, alpha0 = grilla, pct_fondo = props)
}

curva_chile <- curva_sensibilidad(prep_chile_analisis, "Chile")
curva_japon <- curva_sensibilidad(prep_japon_analisis, "Japón")
curva_todos <- bind_rows(curva_chile, curva_japon)
marcadores <- bind_rows(
  curva_sensibilidad(prep_chile_analisis, "Chile", grilla = grilla_alpha0_gruesa),
  curva_sensibilidad(prep_japon_analisis, "Japón", grilla = grilla_alpha0_gruesa)
)

grafico_sensibilidad <- ggplot(curva_todos, aes(x = alpha0, y = pct_fondo, color = Pais)) +
  geom_hline(yintercept = c(0, 25, 50, 75, 100), color = "grey90", linewidth = 0.3) +
  geom_vline(xintercept = 0, color = "grey30", linetype = "dashed", linewidth = 0.5) +
  geom_line(linewidth = 1) +
  geom_point(data = marcadores, size = 1.8) +
  scale_color_manual(values = paleta_pais) +
  scale_y_continuous(limits = c(0, 100), breaks = seq(0, 100, 25)) +
  labs(title = "Sensibilidad del catálogo declusterizado al umbral α0",
       subtitle = sprintf("η₀ (Chile) = %.3g   |   η₀ (Japón) = %.3g   — línea punteada: α0 final (ambos países = 0)",
                           prep_chile$eta0, prep_japon$eta0),
       x = expression("Umbral de clúster, " * alpha[0]), y = "Proporción esperada de eventos de fondo (%)") +
  tema_base_decl

print(grafico_sensibilidad)
ggsave("alpha0_sensibilidad_chile_japon.png", grafico_sensibilidad, width = 9, height = 6, dpi = 200, bg = "white")

# ================================================================================
# B.14 NOTA METODOLÓGICA: HALLAZGO Y DECISIÓN FINAL DE ALPHA0
#
#    BUG ENCONTRADO Y CORREGIDO (documentado también en B.5): leyendo la
#    Sección 4.2 del paper, para un catálogo Poisson (real o sintético)
#    log10(alpha) debería quedar concentrado alrededor de 0 (Ec. 10), y el
#    paper recomienda explorar alpha0 en el rango -1 a 1. La exploración
#    inicial del equipo (alpha0 entre -20 y +8) estaba muy fuera de ese
#    rango. Se generó un catálogo sintético de Poisson puro (sin clustering)
#    y se le aplicó calcular_alpha() tal cual estaba: dio log10(alpha) con
#    mediana ~9, confirmando un bug, no una característica real de los
#    catálogos. La causa era la auto-comparación no excluida en el
#    reshuffling (ver B.5). Corregido: con el catálogo sintético de prueba,
#    log10(alpha) pasó a tener mediana ~0.07 y percentiles [-1.7, 1.0],
#    calzando con la Ec. 10 del paper.
#
#    DECISIÓN FINAL (con calcular_alpha() ya corregido, evidencia de la
#    batería de 50 realizaciones — Sección B.16):
#      Chile: alpha0 = 0. Bridge media=0.783 [0.752,0.814], KS
#             media=0.497 [0.439,0.555], Luen-Stark media=0.893
#             [0.856,0.930] — los tres pasan con margen amplio. En
#             alpha0=0.5 ya rechaza KS (media=0.042, IC bajo 0.05) —
#             confirma que 0 es el borde superior real. % fondo = 33.4%.
#      Japón: alpha0 = 0 (por simetría con Chile; antes se había considerado
#             -0.5). KS pasa en promedio (media=0.100) pero con margen
#             frágil (sd=0.097 -> ~30% de realizaciones individuales bajo
#             0.05, contra <1% en -0.5). Luen-Stark —el criterio decisivo—
#             pasa con margen amplio en 0. Se documenta la fragilidad de KS
#             como limitación conocida del punto elegido, no como motivo de
#             descarte.
#
#    Nota: la Sección "13" del script original (grilla de un solo sorteo por
#    alpha0) quedó SUPERADA por la batería multi-realización (B.16) y no se
#    incluye acá — en el original estaba envuelta en if(FALSE){...} y nunca
#    se ejecutaba.
# ================================================================================

# ================================================================================
# B.15 VERIFICACIÓN DE DISPERSIÓN POISSON (previo a poisson.test() entre países)
#      Se corre con el alpha0 FINAL de cada país (Sección B.14): 0 y 0.
# ================================================================================

verificar_dispersion_poisson <- function(prep_analisis, alpha0_elegido, pais, seed = 999) {
  A0 <- 10^alpha0_elegido
  set.seed(seed)
  U <- runif(length(prep_analisis$alpha))
  es_fondo <- (prep_analisis$alpha * A0) > U
  fondo <- prep_analisis$datos[es_fondo, ]
  conteo <- fondo %>%
    dplyr::mutate(anio = year(time)) %>%
    dplyr::count(anio, name = "n") %>%
    dplyr::right_join(data.frame(anio = 2000:2025), by = "anio") %>%
    dplyr::mutate(n = ifelse(is.na(n), 0, n)) %>%
    dplyr::arrange(anio)
  conteo$anio_c <- as.numeric(scale(conteo$anio))
  modelo <- glm(n ~ poly(anio_c, 3), data = conteo, family = poisson())
  dev <- deviance(modelo); df_resid <- df.residual(modelo)
  p_valor <- 1 - pchisq(dev, df_resid)
  cat(sprintf("%s (alpha0=%.1f, n_fondo=%d): deviance=%.2f, df=%d, deviance/df=%.3f, p-valor=%.4f\n",
              pais, alpha0_elegido, nrow(fondo), dev, df_resid, dev / df_resid, p_valor))
  list(modelo = modelo, conteo = conteo, deviance = dev, df = df_resid, p_valor = p_valor)
}

cat("\n--- Verificación de dispersión Poisson (tras descontar tendencia temporal) ---\n")
chk_chile <- verificar_dispersion_poisson(prep_chile_analisis, alpha0_elegido = 0, pais = "Chile")
chk_japon <- verificar_dispersion_poisson(prep_japon_analisis, alpha0_elegido = 0, pais = "Japón")
summary(chk_chile$modelo); summary(chk_japon$modelo)

# --- B.15.1 Serie anual de fondo: observado vs. tasa ajustada ---
graficar_serie_fondo <- function(chk, pais, color_pais) {
  conteo <- chk$conteo
  conteo$mu <- predict(chk$modelo, type = "response")
  conteo$li <- pmax(conteo$mu - 1.96 * sqrt(conteo$mu), 0)
  conteo$ls <- conteo$mu + 1.96 * sqrt(conteo$mu)
  ggplot(conteo, aes(x = anio)) +
    geom_ribbon(aes(ymin = li, ymax = ls), fill = color_pais, alpha = 0.15) +
    geom_col(aes(y = n), fill = color_pais, alpha = 0.55, width = 0.7) +
    geom_line(aes(y = mu), color = color_pais, linewidth = 1.1) +
    labs(title = paste0("Serie anual de eventos de fondo — ", pais), x = "Año", y = "N° de eventos de fondo") +
    tema_base_decl
}

grafico_serie_chile <- graficar_serie_fondo(chk_chile, "Chile", unname(paleta_pais["Chile"]))
grafico_serie_japon <- graficar_serie_fondo(chk_japon, "Japón", unname(paleta_pais["Japón"]))
print(grafico_serie_chile); print(grafico_serie_japon)
ggsave("serie_fondo_poisson_Chile.png", grafico_serie_chile, width = 8.5, height = 5.5, dpi = 200, bg = "white")
ggsave("serie_fondo_poisson_Japon.png", grafico_serie_japon, width = 8.5, height = 5.5, dpi = 200, bg = "white")

# ================================================================================
# B.16 BATERÍA DE FASE 0 CON MÚLTIPLES REALIZACIONES DE THINNING
#      Grilla [-3,3] por pasos de 0.5, 50 realizaciones de thinning por
#      punto. Esta es la sección que efectivamente decidió el alpha0 final
#      de cada país (Chile=0, Japón=0) — ver nota en B.14.
# ================================================================================

grilla_alpha0_multi <- seq(-3, 3, by = 0.5)
N_REALIZACIONES <- 50

bateria_multi_realizacion <- function(prep_analisis, pais, grilla = grilla_alpha0_multi,
                                       n_realiz = N_REALIZACIONES, M_bridge = 500, M_ls = 60) {
  resultados <- list()
  idx <- 1
  for (a0 in grilla) {
    A0 <- 10^a0
    for (r in 1:n_realiz) {
      set.seed(3000 + r)   # una semilla por realización -> cada punto de la grilla es reproducible
      U <- runif(length(prep_analisis$alpha))
      es_fondo <- (prep_analisis$alpha * A0) > U
      sub <- prep_analisis$datos[es_fondo, ]
      n <- nrow(sub)
      if (n < 10) next
      p_ks <- ks_estacionariedad_pvalue(sub$t_dias)
      p_br <- bridge_pvalue(sub$t_dias, M = M_bridge, seed = 4000 + r)
      p_ls <- luen_stark_pvalue(sub$longitude, sub$latitude, sub$t_dias, M = M_ls, seed = 5000 + r)
      resultados[[idx]] <- data.frame(
        Pais = pais, alpha0 = a0, realizacion = r, n = n,
        `KS (estacionariedad)` = p_ks, `Bridge (estacionariedad)` = p_br,
        `Luen-Stark (espacio-tiempo)` = p_ls, check.names = FALSE
      )
      idx <- idx + 1
    }
  }
  bind_rows(resultados)
}

cat("\nCalculando batería multi-realización (50 realizaciones x 13 puntos de grilla x 2 países)...\n")
multi_chile <- bateria_multi_realizacion(prep_chile_analisis, "Chile")
multi_japon <- bateria_multi_realizacion(prep_japon_analisis, "Japón")
write_csv(multi_chile, "chile_bateria_multi_realizacion.csv")
write_csv(multi_japon, "japon_bateria_multi_realizacion.csv")

resumen_multi <- function(datos_multi) {
  datos_multi %>%
    tidyr::pivot_longer(-c(Pais, alpha0, realizacion, n), names_to = "test", values_to = "p_valor") %>%
    dplyr::group_by(Pais, alpha0, test) %>%
    dplyr::summarise(n_medio = round(mean(n)), pct_no_rechaza = round(100 * mean(p_valor > 0.05, na.rm = TRUE)),
                      p_mediana = round(median(p_valor, na.rm = TRUE), 4), .groups = "drop")
}

cat("\n--- Resumen: % de realizaciones que NO rechazan (p>0.05), por test y alpha0 ---\n")
print(resumen_multi(multi_chile), n = 100)
print(resumen_multi(multi_japon), n = 100)

resumen_multi_curva <- function(datos_multi) {
  datos_multi %>%
    tidyr::pivot_longer(-c(Pais, alpha0, realizacion, n), names_to = "test", values_to = "p_valor") %>%
    dplyr::group_by(Pais, alpha0, test) %>%
    dplyr::summarise(media = mean(p_valor, na.rm = TRUE), sd = sd(p_valor, na.rm = TRUE),
                      n_val = sum(!is.na(p_valor)), .groups = "drop") %>%
    dplyr::mutate(ee = sd / sqrt(n_val), li = pmax(media - 1.96 * ee, 0), ls = pmin(media + 1.96 * ee, 1))
}

graficar_bateria_multi <- function(datos_multi, pais_nombre, eta0, alpha0_final = NULL, n_realiz = N_REALIZACIONES) {
  resumen <- resumen_multi_curva(datos_multi)
  g <- ggplot(resumen, aes(x = alpha0, y = media, color = test, fill = test)) +
    annotate("rect", xmin = -Inf, xmax = Inf, ymin = 0, ymax = 0.05, fill = "#e34948", alpha = 0.06) +
    geom_hline(yintercept = 0.05, linetype = "dashed", color = "grey40")
  if (!is.null(alpha0_final)) g <- g + geom_vline(xintercept = alpha0_final, linetype = "dotted", color = "grey20", linewidth = 0.6)
  subt <- sprintf(
    "%d realizaciones de thinning por punto de la grilla. Línea = p-valor medio; banda = IC 95%% de la media (± 1.96·EE).\nη₀ (%s) = %.3g%s",
    n_realiz, pais_nombre, eta0,
    if (!is.null(alpha0_final)) sprintf(" — línea punteada vertical: α0 final = %.2f", alpha0_final) else ""
  )
  g + geom_ribbon(aes(ymin = li, ymax = ls), color = NA, alpha = 0.15) +
    geom_line(linewidth = 1) +
    geom_point(size = 2, shape = 21, color = "white", stroke = 0.4) +
    scale_color_manual(values = paleta_tests) + scale_fill_manual(values = paleta_tests) +
    scale_x_continuous(breaks = sort(unique(resumen$alpha0))) +
    scale_y_continuous(limits = c(0, 1)) +
    labs(title = paste0("Batería de Fase 0 con múltiples realizaciones — ", pais_nombre), subtitle = subt,
         x = expression("Umbral de clúster, " * alpha[0]), y = "p-valor medio ± IC 95% (sobre las realizaciones)") +
    tema_base_decl + theme(legend.position = "top")
}

grafico_multi_chile <- graficar_bateria_multi(multi_chile, "Chile", prep_chile$eta0, alpha0_final = 0)
grafico_multi_japon <- graficar_bateria_multi(multi_japon, "Japón", prep_japon$eta0, alpha0_final = 0)
print(grafico_multi_chile); print(grafico_multi_japon)
ggsave("bateria_multi_Chile.png", grafico_multi_chile, width = 10, height = 6.4, dpi = 200, bg = "white")
ggsave("bateria_multi_Japon.png", grafico_multi_japon, width = 10, height = 6.4, dpi = 200, bg = "white")

# ================================================================================
# B.17 EVENTOS GENERADOR Y SU PRODUCTIVIDAD DE RÉPLICAS (alpha0 final: 0 y 0)
#      gen_chile/gen_japon traen una fila por cada familia/clúster (incluidas
#      las de 0 réplicas), con el generador reetiquetado como el evento de
#      mayor magnitud de la familia. Se filtra a
#      generador_en_periodo_estudio == TRUE porque interesan los generadores
#      2000-2025 (no los del colchón pre-2000, que solo son candidatos a padre).
# ================================================================================

resumen_generadores <- function(gen_pais, pais) {
  familias_en_periodo <- gen_pais %>% dplyr::filter(generador_en_periodo_estudio)
  stats <- familias_en_periodo %>%
    dplyr::summarise(n_generadores = dplyr::n(), media = mean(n_replicas), sd = sd(n_replicas), mediana = median(n_replicas))
  top10 <- familias_en_periodo %>% dplyr::arrange(desc(n_replicas)) %>% head(10) %>% dplyr::mutate(Pais = pais, .before = 1)
  cat(sprintf("\n--- %s: eventos generador (mayor magnitud del clúster) y réplicas (2000-2025) ---\n", pais))
  cat(sprintf("n° de eventos generador: %d\n", stats$n_generadores))
  cat(sprintf("réplicas por generador: media=%.2f, sd=%.2f, mediana=%.1f\n", stats$media, stats$sd, stats$mediana))
  list(datos = familias_en_periodo, stats = stats, top10 = top10)
}

res_chile <- resumen_generadores(gen_chile, "Chile")
res_japon <- resumen_generadores(gen_japon, "Japón")
cat("\nTop 10 eventos generador con más réplicas — Chile:\n"); print(res_chile$top10)
cat("\nTop 10 eventos generador con más réplicas — Japón:\n"); print(res_japon$top10)

# --- Productividad de réplicas vs. magnitud del generador (ley de
#     Utsu/Reasenberg: el n° esperado de réplicas crece aprox.
#     exponencialmente con la magnitud del generador, es decir
#     log10(n_replicas+1) ~ magnitud es aprox. lineal). Se reporta la
#     correlación de Spearman (robusta a la fuerte asimetría del conteo:
#     muchos ceros, cola larga) y la pendiente de una regresión simple sobre
#     la escala log10(n+1). Esta métrica es la que da pie a la Discusión
#     7.4.2 del informe: si Chile y Japón muestran la misma relación
#     magnitud-productividad, las conclusiones basadas en el catálogo
#     declusterizado (donde se descartan las réplicas) quedan respaldadas
#     también para el catálogo crudo, porque las réplicas se comportan de
#     forma comparable en ambos países.
#
#     NOTA: en el script original esta función y su llamada aparecían DOS
#     VECES, de forma idéntica (probablemente un copy-paste accidental
#     durante la edición). Acá se dejó una sola vez.
productividad_vs_magnitud <- function(datos_generadores, pais) {
  x <- datos_generadores$transMw
  y <- log10(datos_generadores$n_replicas + 1)
  rho <- cor(x, y, method = "spearman")
  modelo <- lm(y ~ x)
  p_pendiente <- summary(modelo)$coefficients[2, 4]
  cat(sprintf("\n%s: correlación Spearman (magnitud, log10(réplicas+1)) = %.3f\n", pais, rho))
  cat(sprintf("Pendiente ajustada: %.3f log10(réplicas+1) por unidad de Mw (p=%.4g)\n", coef(modelo)[2], p_pendiente))
  list(rho = rho, modelo = modelo)
}
prod_chile <- productividad_vs_magnitud(res_chile$datos, "Chile")
prod_japon <- productividad_vs_magnitud(res_japon$datos, "Japón")

# ================================================================================
# B.18 ¿DISTRIBUYEN IGUAL LAS RÉPLICAS POR GENERADOR EN CHILE Y JAPÓN?
#      Se reporta KS de dos muestras (forma completa de la distribución) y
#      Mann-Whitney U (mediana/dominancia estocástica), más la comparación
#      gráfica de las ECDF. Se evaluaron y descartaron Wald-Wolfowitz (deja
#      de ser interpretable con tantos empates como hay acá — muchos ceros)
#      y Siegel-Tukey/Fligner-Killeen para dispersión: como n_replicas es un
#      conteo no-negativo con mediana=0 en ambos países, cualquier test de
#      dispersión basado en distancia a la mediana colapsa algebraicamente al
#      mismo resultado que Mann-Whitney (|x-0|=x para x>=0) — se verificó
#      empíricamente que el p-valor de Siegel-Tukey coincide exactamente con
#      el de Mann-Whitney acá, así que no aporta información independiente.
# ================================================================================

n_chile <- res_chile$datos$n_replicas
n_japon <- res_japon$datos$n_replicas

ks_comparacion <- ks.test(n_chile, n_japon)
cat(sprintf("KS dos muestras: D=%.4f, p=%.4g\n", ks_comparacion$statistic, ks_comparacion$p.value))

mw_comparacion <- wilcox.test(n_chile, n_japon, exact = FALSE)
cat(sprintf("Mann-Whitney U: W=%.1f, p=%.4g\n", mw_comparacion$statistic, mw_comparacion$p.value))

# ECDF comparada, en escala log10(n+1) por la cola larga
datos_comparacion <- dplyr::bind_rows(
  data.frame(Pais = "Chile", n_replicas = n_chile),
  data.frame(Pais = "Japón", n_replicas = n_japon)
) %>% dplyr::mutate(log1p_n = log10(n_replicas + 1))

breaks_originales <- c(0, 1, 2, 5, 10, 25, 50, 100, 250, 500)
breaks_log1p <- log10(breaks_originales + 1)

grafico_ecdf <- ggplot(datos_comparacion, aes(x = log1p_n, color = Pais)) +
  stat_ecdf(geom = "step", linewidth = 1.1) +
  scale_color_manual(values = paleta_pais) +
  scale_x_continuous(breaks = breaks_log1p, labels = breaks_originales) +
  labs(title = "Función de distribución empírica: réplicas por generador",
       subtitle = sprintf("Chile vs. Japón — KS: D=%.3f, p=%.3g | Mann-Whitney: p=%.3g",
                           ks_comparacion$statistic, ks_comparacion$p.value, mw_comparacion$p.value),
       x = "N° de réplicas por generador", y = "Proporción acumulada (ECDF)") +
  tema_base_decl
print(grafico_ecdf)
ggsave("ecdf_replicas_generador.png", grafico_ecdf, width = 9, height = 6, dpi = 200, bg = "white")

# Distribución (no acumulada) del n° de réplicas por generador — ridgeline
grafico_dist <- ggplot(datos_comparacion, aes(x = log1p_n, y = Pais, fill = Pais)) +
  geom_density_ridges(alpha = 0.8, color = "white", scale = 1.4, linewidth = 0.5) +
  scale_fill_manual(values = paleta_pais) +
  scale_x_continuous(breaks = breaks_log1p, labels = breaks_originales) +
  scale_y_discrete(expand = expansion(mult = c(0.02, 0.35))) +
  coord_cartesian(clip = "off") +
  labs(title = "Distribución del n° de réplicas por generador",
       subtitle = "Chile vs. Japón — eje horizontal en escala log10(n+1) por la cola larga",
       x = "N° de réplicas por generador", y = NULL) +
  tema_base_decl + theme(legend.position = "none")
print(grafico_dist)
ggsave("distribucion_replicas_generador.png", grafico_dist, width = 9, height = 5.5, dpi = 200, bg = "white")

# ================================================================================
# B.19 COMPARACIÓN DE TASAS DE OCURRENCIA ENTRE PAÍSES (catálogo de fondo completo)
# ================================================================================

# LRT clásico: H0: lambda_Chile = lambda_Japón = lambda_pool vs H1: tasas libres.
# n = conteo total de sismos de fondo, T = años de exposición (26; 2000-2025).
lrt_dos_tasas_poisson <- function(n1, T1, n2, T2) {
  lambda1_hat <- n1 / T1; lambda2_hat <- n2 / T2
  lambda_pool <- (n1 + n2) / (T1 + T2)
  # log-verosimilitud Poisson(lambda*T) (se omite log(n!): no depende de lambda,
  # se cancela en la razón de verosimilitudes)
  loglik <- function(n, T, lambda) n * log(lambda * T) - lambda * T
  logL_H1 <- loglik(n1, T1, lambda1_hat) + loglik(n2, T2, lambda2_hat)
  logL_H0 <- loglik(n1, T1, lambda_pool)  + loglik(n2, T2, lambda_pool)
  estadistico <- -2 * (logL_H0 - logL_H1)
  p_valor <- 1 - pchisq(estadistico, df = 1)
  list(lambda1_hat = lambda1_hat, lambda2_hat = lambda2_hat, lambda_pool = lambda_pool,
       estadistico = estadistico, p.value = p_valor)
}

n_chile_total <- sum(chk_chile$conteo$n); T_chile <- nrow(chk_chile$conteo)
n_japon_total <- sum(chk_japon$conteo$n); T_japon <- nrow(chk_japon$conteo)

lrt_resultado <- lrt_dos_tasas_poisson(n_chile_total, T_chile, n_japon_total, T_japon)
cat(sprintf("LRT: lambda_Chile=%.2f, lambda_Japón=%.2f, estadístico=%.3f, p=%.4g\n",
            lrt_resultado$lambda1_hat, lrt_resultado$lambda2_hat, lrt_resultado$estadistico, lrt_resultado$p.value))

# Intervalos de confianza EXACTOS para cada tasa individual (relación exacta
# Poisson <-> chi-cuadrado, no aproximación normal)
ic_chile <- poisson.test(n_chile_total, T_chile)$conf.int
ic_japon <- poisson.test(n_japon_total, T_japon)$conf.int
cat(sprintf("Chile: lambda_hat=%.2f eventos/año, IC95%%=[%.2f, %.2f]\n", n_chile_total / T_chile, ic_chile[1], ic_chile[2]))
cat(sprintf("Japón: lambda_hat=%.2f eventos/año, IC95%%=[%.2f, %.2f]\n", n_japon_total / T_japon, ic_japon[1], ic_japon[2]))

# Test exacto de Poisson de dos muestras: IC para la RAZÓN de tasas
# (lambda_Chile / lambda_Japón) — pregunta distinta a los IC individuales de
# arriba ("¿cuántas veces más grande es una tasa que la otra?").
pt_resultado <- poisson.test(x = c(n_chile_total, n_japon_total), T = c(T_chile, T_japon))
print(pt_resultado)
cat(sprintf("Razón de tasas Chile/Japón = %.3f, IC95%%=[%.3f, %.3f]\n",
            pt_resultado$estimate, pt_resultado$conf.int[1], pt_resultado$conf.int[2]))

# ================================================================================
# B.20 TIEMPO ENTRE EVENTOS DE FONDO (general, catálogo declusterizado completo)
# ================================================================================
# NOTA DE ORDEN: en el script original, esta sección (y la B.21 que sigue)
# usaban fondo_chile/fondo_japon y dt_chile/dt_japon casi 500 líneas ANTES de
# que esos objetos se calcularan (aparecían recién en lo que acá es la
# Sección B.24). Ejecutado tal cual, el script original habría fallado con
# "object 'fondo_chile' not found" / "object 'dt_chile' not found" en este
# punto. Acá se adelanta el cálculo de fondo_chile/fondo_japon y se define
# tiempos_entre_eventos() ANTES de usarla (en el original se definía más
# abajo, después de su primer uso).

# --- B.20.0 Subconjunto de fondo por país (catálogo declusterizado, es_fondo==TRUE) ---
# Nota: Mw_cat ya viene calculada desde cargar_pais() (Sección B.1); no hace
# falta recalcularla acá (en el script original se recalculaba de forma
# redundante con exactamente la misma fórmula — se simplifica).
fondo_chile <- chile_decl_analisis %>% dplyr::filter(es_fondo, !is.na(Mw_cat))
fondo_japon <- japon_decl_analisis %>% dplyr::filter(es_fondo, !is.na(Mw_cat))

# --- B.20.1 Tiempos entre eventos consecutivos de fondo ---
tiempos_entre_eventos <- function(datos_generadores) {
  t_ordenados <- sort(datos_generadores$time)
  as.numeric(diff(t_ordenados), units = "days")
}

dt_chile <- tiempos_entre_eventos(fondo_chile)
dt_japon <- tiempos_entre_eventos(fondo_japon)

# --- B.20.2 Tabla descriptiva ---
tabla_dt <- data.frame(
  Pais = c("Chile", "Japón"), n = c(length(dt_chile), length(dt_japon)),
  Media = c(mean(dt_chile), mean(dt_japon)), DE = c(sd(dt_chile), sd(dt_japon)),
  Mediana = c(median(dt_chile), median(dt_japon)), Minimo = c(min(dt_chile), min(dt_japon)),
  Maximo = c(max(dt_chile), max(dt_japon))
) %>% dplyr::mutate(dplyr::across(where(is.numeric) & !n, ~round(., 1)))
print(tabla_dt)

# --- B.20.3 Figura de 3 paneles: cajas y bigotes | ECDF | densidad ---
# (el script original probaba primero una versión con QQ-plot en el panel
# central y la reemplazaba, 15 líneas después, por la versión con ECDF que
# es la que efectivamente coincide con la Figura del informe. Se deja acá
# solo la versión final con ECDF, para no imprimir dos figuras redundantes.)
df_dt <- dplyr::bind_rows(data.frame(dt = dt_chile, Pais = "Chile"), data.frame(dt = dt_japon, Pais = "Japón"))

grafico_box <- ggplot(df_dt, aes(x = Pais, y = dt, fill = Pais)) +
  geom_boxplot(alpha = 0.75, color = "black", outlier.alpha = 0.4) +
  scale_fill_manual(values = paleta_pais) +
  scale_y_log10(labels = scales::label_number()) +
  labs(x = NULL, y = "Días entre eventos (escala log)", title = "Cajas y bigotes") +
  tema_base_decl + theme(legend.position = "none")

grafico_ecdf_dt <- ggplot(df_dt, aes(x = dt, color = Pais)) +
  stat_ecdf(geom = "step", linewidth = 1.1) +
  scale_color_manual(values = paleta_pais) +
  scale_x_log10(labels = scales::label_number()) +
  labs(x = "Días entre eventos (escala log)", y = "Proporción acumulada (ECDF)", title = "ECDF") +
  tema_base_decl

grafico_dens <- ggplot(df_dt, aes(x = dt, fill = Pais, color = Pais)) +
  geom_density(alpha = 0.4, linewidth = 0.8) +
  scale_fill_manual(values = paleta_pais) + scale_color_manual(values = paleta_pais) +
  scale_x_log10(labels = scales::label_number()) +
  labs(x = "Días entre eventos (escala log)", y = "Densidad", title = "Densidad") +
  tema_base_decl

figura_tiempos <- (grafico_box | grafico_ecdf_dt | grafico_dens) +
  patchwork::plot_annotation(title = "Tiempo entre eventos de fondo: Chile vs Japón")
print(figura_tiempos)
# ggsave("figura_tiempos_fondo.png", figura_tiempos, width = 13, height = 4.5, dpi = 300)

# --- B.20.4 LRT exponencial ---
lrt_dos_tasas_exponencial <- function(t1, t2) {
  n1 <- length(t1); n2 <- length(t2)
  s1 <- sum(t1); s2 <- sum(t2)
  lambda1_hat <- n1 / s1; lambda2_hat <- n2 / s2
  lambda_pool <- (n1 + n2) / (s1 + s2)
  loglik <- function(n, s, lambda) n * log(lambda) - lambda * s
  logL_H1 <- loglik(n1, s1, lambda1_hat) + loglik(n2, s2, lambda2_hat)
  logL_H0 <- loglik(n1, s1, lambda_pool)  + loglik(n2, s2, lambda_pool)
  estadistico <- -2 * (logL_H0 - logL_H1)
  p_valor <- 1 - pchisq(estadistico, df = 1)
  list(lambda1_hat = lambda1_hat, lambda2_hat = lambda2_hat, lambda_pool = lambda_pool,
       estadistico = estadistico, p.value = p_valor)
}

lrt_exp <- lrt_dos_tasas_exponencial(dt_chile, dt_japon)
cat(sprintf("LRT exponencial: lambda_Chile=%.4f, lambda_Japon=%.4f, estadistico=%.3f, p=%.4g\n",
            lrt_exp$lambda1_hat, lrt_exp$lambda2_hat, lrt_exp$estadistico, lrt_exp$p.value))

# --- B.20.5 KS y Mann-Whitney sobre los tiempos entre eventos ---
# NOTA: en el script original, ks_dt/mw_dt se USABAN en tabla_tiempos (más
# abajo) pero nunca se calculaban explícitamente en ningún punto anterior
# del archivo — otro caso de objeto usado antes de definirse (o definido en
# una sesión de RStudio previa que no quedó en el script). Se agregan acá,
# siguiendo exactamente el mismo patrón que la Sección B.21 usa para el
# subconjunto M>6.5 (donde sí estaban explícitos: ks_dt65/mw_dt65).
ks_dt <- ks.test(dt_chile, dt_japon)
mw_dt <- wilcox.test(dt_chile, dt_japon)

# --- B.20.6 Siegel-Tukey (dispersión), centrado por la mediana propia de cada país ---
# NOTA: el script original definía DOS funciones distintas con el mismo
# nombre "siegel_tukey" (esta, centrada en la mediana; y otra, basada en el
# recorrido de rangos de Siegel-Tukey clásico, usada más abajo en B.30 dentro
# de comparar_distribuciones()). La segunda definición sobreescribía
# silenciosamente a esta. Se renombra esta a siegel_tukey_centrado() para que
# ambas convivan sin choque.
siegel_tukey_rangos <- function(valores) {
  n <- length(valores)
  orden <- order(valores)
  rango_st <- integer(n)
  izq <- 1; der <- n; k <- 1; desde_abajo <- TRUE
  while (izq <= der) {
    if (desde_abajo) { rango_st[orden[izq]] <- k; izq <- izq + 1 }
    else              { rango_st[orden[der]] <- k; der <- der - 1 }
    k <- k + 1
    desde_abajo <- !desde_abajo
  }
  rango_st
}

siegel_tukey_centrado <- function(x, y) {
  x_c <- x - median(x); y_c <- y - median(y)
  combinado <- c(x_c, y_c)
  grupo <- c(rep("x", length(x_c)), rep("y", length(y_c)))
  rangos <- siegel_tukey_rangos(combinado)
  rangos <- ave(rangos, combinado, FUN = mean)  # empates -> rango promedio
  rango_x <- rangos[grupo == "x"]; rango_y <- rangos[grupo == "y"]
  test <- wilcox.test(rango_x, rango_y, exact = FALSE)
  list(rango_medio_x = mean(rango_x), rango_medio_y = mean(rango_y), W = unname(test$statistic), p.value = test$p.value)
}

st_dt <- siegel_tukey_centrado(dt_chile, dt_japon)
cat(sprintf("Siegel-Tukey (centrado): rango medio Chile=%.1f, rango medio Japón=%.1f, W=%.1f, p=%.4g\n",
            st_dt$rango_medio_x, st_dt$rango_medio_y, st_dt$W, st_dt$p.value))

# --- B.20.7 Tabla resumen: LRT exponencial + KS + Mann-Whitney + Siegel-Tukey (custom) ---
tabla_tiempos <- data.frame(
  Test = c("Razón de Verosimilitud (exponencial)", "KS dos muestras", "Mann-Whitney U", "Siegel-Tukey (dispersión, centrado)"),
  Estadistico = round(c(lrt_exp$estadistico, unname(ks_dt$statistic), unname(mw_dt$statistic), st_dt$W), 3),
  gl = c(1, NA, NA, NA),
  Valor_p = formatC(c(lrt_exp$p.value, ks_dt$p.value, mw_dt$p.value, st_dt$p.value), format = "e", digits = 3)
)
print(tabla_tiempos)

# --- B.20.8 Segunda versión de Siegel-Tukey, con DescTools (más estándar) ---
# IMPORTANTE: esta es una implementación DISTINTA a siegel_tukey_centrado()
# (arriba). Si el Cuadro del informe reporta un valor de Siegel-Tukey que no
# calza con st_dt (B.20.6), es casi seguro que el que se usó fue este
# (st_result), no el custom — conviene verificarlo contra el informe.
st_result <- SiegelTukeyTest(dt_chile, dt_japon, adjust.median = TRUE)
print(st_result)
cat(sprintf("Siegel-Tukey (DescTools, adjust.median=TRUE): estadístico=%.3f, p=%.4g\n", st_result$statistic, st_result$p.value))

# ================================================================================
# B.21 SUBCONJUNTO Mw > 6.5: RÉPLICA COMPLETA DEL ANÁLISIS DE SENSIBILIDAD
#      (mismo desarrollo de B.19-B.20, pero solo sobre eventos de fondo
#      fuertes — el análisis de sensibilidad al umbral de magnitud que pide
#      el TdR, Sección 7.4.1 del informe)
# ================================================================================

chile_fuerte65 <- dplyr::filter(res_chile$datos, transMw > 6.5)
japon_fuerte65 <- dplyr::filter(res_japon$datos, transMw > 6.5)
cat(sprintf("Chile: n=%d eventos de fondo M>6.5\n", nrow(chile_fuerte65)))
cat(sprintf("Japón: n=%d eventos de fondo M>6.5\n", nrow(japon_fuerte65)))

# --- B.21.1 ¿Siguen un proceso de Poisson homogéneo? (mismos 3 tests de Fase 0) ---
dias_desde_inicio <- function(datos) as.numeric(datos$time - min(datos$time), units = "days")

t_chile65 <- dias_desde_inicio(chile_fuerte65)
t_japon65 <- dias_desde_inicio(japon_fuerte65)

p_ks_chile65 <- ks_estacionariedad_pvalue(t_chile65)
p_ks_japon65 <- ks_estacionariedad_pvalue(t_japon65)
p_bridge_chile65 <- bridge_pvalue(t_chile65, M = 2000, seed = 8001)
p_bridge_japon65 <- bridge_pvalue(t_japon65, M = 2000, seed = 8002)
p_ls_chile65 <- luen_stark_pvalue(chile_fuerte65$longitude, chile_fuerte65$latitude, t_chile65, M = 200, seed = 8003)
p_ls_japon65 <- luen_stark_pvalue(japon_fuerte65$longitude, japon_fuerte65$latitude, t_japon65, M = 200, seed = 8004)

tabla_estacionariedad65 <- data.frame(
  Pais = c("Chile", "Japón"), n = c(nrow(chile_fuerte65), nrow(japon_fuerte65)),
  KS_p = c(p_ks_chile65, p_ks_japon65), Bridge_p = c(p_bridge_chile65, p_bridge_japon65),
  LuenStark_p = c(p_ls_chile65, p_ls_japon65)
)
print(tabla_estacionariedad65)

# --- B.21.2 Comparación de la tasa de ocurrencia entre regiones (M>6.5) ---
n_chile65 <- nrow(chile_fuerte65); n_japon65 <- nrow(japon_fuerte65)
lambda_chile65 <- n_chile65 / T_chile; lambda_japon65 <- n_japon65 / T_japon
ic_chile65 <- poisson.test(n_chile65, T_chile)$conf.int
ic_japon65 <- poisson.test(n_japon65, T_japon)$conf.int
cat(sprintf("Chile M>6.5: n=%d, lambda_hat=%.3f eventos/año, IC95%%=[%.3f, %.3f]\n", n_chile65, lambda_chile65, ic_chile65[1], ic_chile65[2]))
cat(sprintf("Japón M>6.5: n=%d, lambda_hat=%.3f eventos/año, IC95%%=[%.3f, %.3f]\n", n_japon65, lambda_japon65, ic_japon65[1], ic_japon65[2]))

lrt_65 <- lrt_dos_tasas_poisson(n_chile65, T_chile, n_japon65, T_japon)
cat(sprintf("LRT: estadístico=%.3f, gl=1, p=%.4g\n", lrt_65$estadistico, lrt_65$p.value))

pt_65 <- poisson.test(x = c(n_chile65, n_japon65), T = c(T_chile, T_japon))
cat(sprintf("Test exacto Poisson: razón tasas=%.3f, IC95%%=[%.3f, %.3f], p=%.4g\n",
            pt_65$estimate, pt_65$conf.int[1], pt_65$conf.int[2], pt_65$p.value))

# --- B.21.3 Tiempo entre eventos de fondo M>=6.5, por país ---
dt_chile65 <- tiempos_entre_eventos(chile_fuerte65)
dt_japon65 <- tiempos_entre_eventos(japon_fuerte65)

tabla_dt65 <- data.frame(
  Pais = c("Chile", "Japón"), n = c(length(dt_chile65), length(dt_japon65)),
  Media = c(mean(dt_chile65), mean(dt_japon65)), DE = c(sd(dt_chile65), sd(dt_japon65)),
  Mediana = c(median(dt_chile65), median(dt_japon65)), Minimo = c(min(dt_chile65), min(dt_japon65)),
  Maximo = c(max(dt_chile65), max(dt_japon65))
) %>% dplyr::mutate(dplyr::across(where(is.numeric) & !n, ~round(., 1)))
print(tabla_dt65)

df_dt65 <- dplyr::bind_rows(data.frame(dt = dt_chile65, Pais = "Chile"), data.frame(dt = dt_japon65, Pais = "Japón"))

grafico_box65 <- ggplot(df_dt65, aes(x = Pais, y = dt, fill = Pais)) +
  geom_boxplot(alpha = 0.75, color = "black", outlier.alpha = 0.4) +
  scale_fill_manual(values = paleta_pais) +
  scale_y_log10(labels = scales::label_number()) +
  labs(x = NULL, y = "Días entre eventos ", title = "Cajas y bigotes") +
  tema_base_decl + theme(legend.position = "none")

grafico_ecdf65 <- ggplot(df_dt65, aes(x = dt, color = Pais)) +
  stat_ecdf(geom = "step", linewidth = 1.1) +
  scale_color_manual(values = paleta_pais) +
  scale_x_log10(labels = scales::label_number()) +
  labs(x = "Días entre eventos ", y = "Proporción acumulada", title = "ECDF") +
  tema_base_decl

grafico_dens65 <- ggplot(df_dt65, aes(x = dt, fill = Pais, color = Pais)) +
  geom_density(alpha = 0.4, linewidth = 0.8) +
  scale_fill_manual(values = paleta_pais) + scale_color_manual(values = paleta_pais) +
  scale_x_log10(labels = scales::label_number()) +
  labs(x = "Días entre eventos", y = "Densidad", title = "Densidad") +
  tema_base_decl

figura_tiempos65 <- (grafico_box65 | grafico_ecdf65 | grafico_dens65) +
  patchwork::plot_annotation(title = "Tiempo entre eventos de fondo M≥6.5: Chile vs Japón")
print(figura_tiempos65)
# ggsave("figura_tiempos_fondo_65.png", figura_tiempos65, width = 13, height = 4.5, dpi = 300)

# --- B.21.4 LRT exponencial + KS + Mann-Whitney + Siegel-Tukey (subconjunto M>6.5) ---
lrt_exp65 <- lrt_dos_tasas_exponencial(dt_chile65, dt_japon65)
ks_dt65   <- ks.test(dt_chile65, dt_japon65)
mw_dt65   <- wilcox.test(dt_chile65, dt_japon65)   # exact=NULL: R decide solo, dado el n chico

# Siegel-Tukey (DescTools) puede fallar con el subconjunto M>6.5 porque es
# chico: con adjust.median=TRUE, el método descarta internamente la
# observación igual a la mediana de cada grupo cuando ese grupo tiene n
# impar: si el grupo ya venía con muy pocos tiempos entre eventos (esperable
# en un subconjunto de eventos fuertes), puede quedar sin observaciones para
# comparar y wilcox.test() interno revienta con "not enough 'y' observations"
# — aunque el wilcox.test() de más arriba (mw_dt65, sin ajustar por mediana)
# sí haya funcionado con esos mismos datos. Se protege con tryCatch: si
# falla, la fila de Siegel-Tukey queda en NA en vez de detener el script, y
# se avisa por consola cuántas observaciones tenía cada país.
st_result65 <- tryCatch(
  SiegelTukeyTest(dt_chile65, dt_japon65, adjust.median = TRUE),
  error = function(e) {
    cat(sprintf(
      "Aviso: Siegel-Tukey (M>=6.5) no se pudo calcular (n_chile65=%d, n_japon65=%d): %s\n",
      length(dt_chile65), length(dt_japon65), conditionMessage(e)
    ))
    list(statistic = NA_real_, p.value = NA_real_)
  }
)

tabla_tiempos65 <- data.frame(
  Test = c("Razón de Verosimilitud (exponencial)", "KS dos muestras", "Mann-Whitney U",
           "Siegel-Tukey (DescTools, adjust.median=TRUE)"),
  Estadistico = round(c(lrt_exp65$estadistico, unname(ks_dt65$statistic), unname(mw_dt65$statistic), unname(st_result65$statistic)), 3),
  gl = c(1, NA, NA, NA),
  Valor_p = formatC(c(lrt_exp65$p.value, ks_dt65$p.value, mw_dt65$p.value, st_result65$p.value), format = "e", digits = 3)
)
print(tabla_tiempos65)

# ================================================================================
# B.22 BONDAD DE AJUSTE EXPONENCIAL (Lilliefors-KS), subconjunto M>=6.5
# ================================================================================
# (chile_fuerte65/japon_fuerte65/dt_chile65/dt_japon65 ya están calculados en
# B.21; el script original los volvía a filtrar/recalcular acá de forma
# redundante — se omite esa repetición.)

lc_chile65 <- LcKS(dt_chile65, cdf = "pexp", nreps = 4999)
lc_japon65 <- LcKS(dt_japon65, cdf = "pexp", nreps = 4999)
cat(sprintf("Chile — bondad de ajuste exponencial (Lilliefors-KS): D=%.4f, p=%.4g\n", lc_chile65$D.obs, lc_chile65$p.value))
cat(sprintf("Japón — bondad de ajuste exponencial (Lilliefors-KS): D=%.4f, p=%.4g\n", lc_japon65$D.obs, lc_japon65$p.value))

# ================================================================================
# B.23 TENDENCIA TEMPORAL: MODELOS POISSON LINEALES Y LRT (catálogo de fondo completo)
# ================================================================================
# Modelo simple n ~ anio (distinto del modelo cúbico n ~ poly(anio_c,3) de
# B.15, que buscaba equidispersión; este busca solo si hay tendencia lineal
# significativa en el tiempo — corresponde a los Cuadros 14/15 del informe).

modelo_nulo_chile   <- glm(n ~ 1,    data = chk_chile$conteo, family = poisson())
modelo_lineal_chile <- glm(n ~ anio, data = chk_chile$conteo, family = poisson())
summary(modelo_nulo_chile); summary(modelo_lineal_chile)
anova(modelo_nulo_chile, modelo_lineal_chile, test = "Chisq")

modelo_nulo_japon   <- glm(n ~ 1,    data = chk_japon$conteo, family = poisson())
modelo_lineal_japon <- glm(n ~ anio, data = chk_japon$conteo, family = poisson())
summary(modelo_nulo_japon); summary(modelo_lineal_japon)
anova(modelo_nulo_japon, modelo_lineal_japon, test = "Chisq")

# LRT manual vía logLik(), como verificación cruzada de anova(..., test="Chisq")
lrt_manual <- function(modelo_nulo, modelo_alt) {
  ll_nulo <- logLik(modelo_nulo); ll_alt <- logLik(modelo_alt)
  estadistico <- -2 * (as.numeric(ll_nulo) - as.numeric(ll_alt))
  gl <- attr(ll_alt, "df") - attr(ll_nulo, "df")
  p_valor <- 1 - pchisq(estadistico, df = gl)
  list(estadistico = estadistico, gl = gl, p.value = p_valor)
}

lrt_tendencia_chile <- lrt_manual(modelo_nulo_chile, modelo_lineal_chile)
cat(sprintf("Chile — LRT manual: estadístico=%.4f, gl=%d, p=%.5f\n",
            lrt_tendencia_chile$estadistico, lrt_tendencia_chile$gl, lrt_tendencia_chile$p.value))

lrt_tendencia_japon <- lrt_manual(modelo_nulo_japon, modelo_lineal_japon)
cat(sprintf("Japón — LRT manual: estadístico=%.4f, gl=%d, p=%.5f\n",
            lrt_tendencia_japon$estadistico, lrt_tendencia_japon$gl, lrt_tendencia_japon$p.value))

# ================================================================================
# B.24 PROPORCIÓN DE "MODERATE" CONSTANTE EN EL TIEMPO — CHILE Y JAPÓN
#      (catálogo de independientes, es_fondo == TRUE; fondo_chile/fondo_japon
#      ya se calcularon en B.20.0)
# ================================================================================

# --- Chile ---
tabla_conteo_chile <- fondo_chile %>%
  dplyr::mutate(anio = lubridate::year(time), estado = ifelse(Mw_cat == "Moderate", "Moderate", "No_moderate")) %>%
  dplyr::count(anio, estado) %>%
  tidyr::complete(anio = 2000:2025, estado = c("Moderate", "No_moderate"), fill = list(n = 0)) %>%
  tidyr::pivot_wider(names_from = estado, values_from = n)

tabla_prop_observada_chile <- tabla_conteo_chile %>%
  dplyr::mutate(total = Moderate + No_moderate, prop_observada = round(Moderate / total, 4)) %>%
  dplyr::select(anio, Moderate, total, prop_observada)
print(tabla_prop_observada_chile, n = Inf)

matriz_chile <- tabla_conteo_chile %>% tibble::column_to_rownames("anio") %>% as.matrix()
chisq_chile <- chisq.test(matriz_chile)
chisq_chile

tabla_prop_esperada_chile <- as.data.frame(chisq_chile$expected) %>%
  tibble::rownames_to_column("anio") %>%
  dplyr::mutate(total_esp = Moderate + No_moderate, prop_esperada = round(Moderate / total_esp, 4)) %>%
  dplyr::select(anio, Moderate_esperado = Moderate, prop_esperada)
print(tabla_prop_esperada_chile)

# Validez de la aproximación chi-cuadrado (regla de Cochran: <20% de las
# celdas esperadas bajo 5, y ninguna en 0)
mean(chisq_chile$expected < 5); min(chisq_chile$expected)

# --- Japón ---
tabla_conteo_japon <- fondo_japon %>%
  dplyr::mutate(anio = lubridate::year(time), estado = ifelse(Mw_cat == "Moderate", "Moderate", "No_moderate")) %>%
  dplyr::count(anio, estado) %>%
  tidyr::complete(anio = 2000:2025, estado = c("Moderate", "No_moderate"), fill = list(n = 0)) %>%
  tidyr::pivot_wider(names_from = estado, values_from = n)

tabla_prop_observada_japon <- tabla_conteo_japon %>%
  dplyr::mutate(total = Moderate + No_moderate, prop_observada = round(Moderate / total, 4)) %>%
  dplyr::select(anio, Moderate, total, prop_observada)
print(tabla_prop_observada_japon, n = Inf)

matriz_japon <- tabla_conteo_japon %>% tibble::column_to_rownames("anio") %>% as.matrix()
chisq_japon <- chisq.test(matriz_japon)
mean(chisq_japon$expected < 5); min(chisq_japon$expected)

tabla_prop_esperada_japon <- as.data.frame(chisq_japon$expected) %>%
  tibble::rownames_to_column("anio") %>%
  dplyr::mutate(total_esp = Moderate + No_moderate, prop_esperada = round(Moderate / total_esp, 4)) %>%
  dplyr::select(anio, Moderate_esperado = Moderate, prop_esperada)
print(tabla_prop_esperada_japon)
chisq_japon

# ================================================================================
# B.25 PROFUNDIDAD DENTRO DE "MODERATE", POR PAÍS (país x depth_cat)
# ================================================================================
# [RECONSTRUIDO] moderate_chile/moderate_japon se usaban en el script
# original (para armar base_depth_moderate, más abajo) pero no se calculaban
# en ningún punto visible del archivo entregado. Siguiendo el mismo patrón
# que el resto de esta sección (filtrar fondo_<pais> a Mw_cat == "Moderate"),
# se reconstruyen acá. Conviene verificar los conteos resultantes contra el
# Cuadro correspondiente del informe (proporción por profundidad dentro de
# la categoría Moderate).
moderate_chile <- fondo_chile %>% dplyr::filter(Mw_cat == "Moderate")
moderate_japon <- fondo_japon %>% dplyr::filter(Mw_cat == "Moderate")

base_depth_moderate <- dplyr::bind_rows(
  moderate_chile %>% dplyr::mutate(pais = "Chile"),
  moderate_japon %>% dplyr::mutate(pais = "Japón")
)

tabla_prop_depth_moderate <- base_depth_moderate %>%
  dplyr::count(pais, depth_cat) %>%
  dplyr::group_by(pais) %>%
  dplyr::mutate(proporcion = round(n / sum(n), 4)) %>%
  dplyr::ungroup()
print(tabla_prop_depth_moderate)

tabla_depth_moderate <- base_depth_moderate %>%
  dplyr::count(pais, depth_cat) %>%
  tidyr::pivot_wider(names_from = depth_cat, values_from = n, values_fill = 0)
print(tabla_depth_moderate)

matriz_depth_moderate <- tabla_depth_moderate %>% tibble::column_to_rownames("pais") %>% as.matrix()
chisq_depth_moderate <- chisq.test(matriz_depth_moderate)
chisq_depth_moderate
mean(chisq_depth_moderate$expected < 5); min(chisq_depth_moderate$expected)

# Respaldo simulado (por si Cochran falla, algo probable si "Profunda"
# aporta muy pocos casos dentro del subconjunto Moderate)
chisq_depth_moderate_sim <- chisq.test(matriz_depth_moderate, simulate.p.value = TRUE, B = 10000)
chisq_depth_moderate_sim

tabla_esperados_depth_moderate <- as.data.frame(round(chisq_depth_moderate$expected, 2)) %>% tibble::rownames_to_column("pais")
print(tabla_esperados_depth_moderate)

tabla_esperados_prop_depth_moderate <- as.data.frame(chisq_depth_moderate$expected) %>%
  tibble::rownames_to_column("pais") %>%
  tidyr::pivot_longer(-pais, names_to = "depth_cat", values_to = "esperado") %>%
  dplyr::group_by(pais) %>%
  dplyr::mutate(proporcion_esperada = round(esperado / sum(esperado), 4)) %>%
  dplyr::ungroup() %>%
  dplyr::mutate(esperado = round(esperado, 2))
print(tabla_esperados_prop_depth_moderate)

# ================================================================================
# B.26 COMPOSICIÓN DE PROFUNDIDAD POR FOSA (chi-cuadrado y Z de proporciones)
# ================================================================================
# [RECONSTRUIDO] tabla_fosa_depth se usaba en el script original pero no se
# calculaba en ningún punto visible del archivo entregado — probablemente
# ya existía en el entorno de RStudio del autor desde una corrida anterior
# de A.2/A.11 (fosa_label solo se calcula sobre 'datos', el catálogo CRUDO de
# la Parte A). Acá se reconstruye aplicando calcular_fosa_cercana() (Sección
# A.2) al catálogo de FONDO declusterizado (fondo_chile + fondo_japon), que
# es el que corresponde usar en el desarrollo inferencial de la Sección 6.
# Verificar los conteos contra los Cuadros de composición por fosa del
# informe antes de dar esta sección por definitiva.
fondo_todos_geo <- dplyr::bind_rows(fondo_chile, fondo_japon) %>%
  calcular_fosa_cercana(trench_m) %>%
  dplyr::mutate(fosa_label = dplyr::case_when(fosa == "RYUKU TRENCH" ~ "RYUKYU TRENCH", TRUE ~ fosa))

tabla_fosa_depth <- fondo_todos_geo %>%
  dplyr::filter(!is.na(depth_cat), !is.na(fosa_label)) %>%
  dplyr::count(fosa_label, depth_cat) %>%
  tidyr::pivot_wider(names_from = depth_cat, values_from = n, values_fill = 0)
print(tabla_fosa_depth)

# --- Parte A: "poco profunda" entre TODAS las fosas ---
tabla_poco_profunda <- tabla_fosa_depth %>%
  dplyr::mutate(No_poco_profunda = Intermedia + Profunda) %>%
  dplyr::select(fosa_label, `Poco profunda`, No_poco_profunda)
print(tabla_poco_profunda)

matriz_poco_profunda <- tabla_poco_profunda %>% tibble::column_to_rownames("fosa_label") %>% as.matrix()
chisq_poco_profunda <- chisq.test(matriz_poco_profunda)
chisq_poco_profunda
mean(chisq_poco_profunda$expected < 5); min(chisq_poco_profunda$expected)

tabla_esperados_poco_profunda <- as.data.frame(round(chisq_poco_profunda$expected, 2)) %>% tibble::rownames_to_column("fosa_label")
print(tabla_esperados_poco_profunda)

# --- Parte B, paso 1: "intermedia" SOLO entre las 5 fosas japonesas ---
tabla_intermedia_japon <- tabla_fosa_depth %>%
  dplyr::filter(fosa_label != "PERU-CHILE TRENCH") %>%
  dplyr::mutate(No_intermedia = `Poco profunda` + Profunda) %>%
  dplyr::select(fosa_label, Intermedia, No_intermedia)
print(tabla_intermedia_japon)

matriz_intermedia_japon <- tabla_intermedia_japon %>% tibble::column_to_rownames("fosa_label") %>% as.matrix()
chisq_intermedia_japon <- chisq.test(matriz_intermedia_japon)
chisq_intermedia_japon
mean(chisq_intermedia_japon$expected < 5); min(chisq_intermedia_japon$expected)

tabla_esperados_intermedia_japon <- as.data.frame(round(chisq_intermedia_japon$expected, 2)) %>% tibble::rownames_to_column("fosa_label")
print(tabla_esperados_intermedia_japon)

# --- Parte B, paso 2: Z de dos proporciones, Peru-Chile Trench vs. cada fosa
#     japonesa, para "Intermedia" (sin corrección) ---
fosas_japon <- c("BONIN TRENCH", "JAPAN TRENCH", "KURIL TRENCH", "NANKAI TROUGH", "RYUKYU TRENCH")

fila_chile <- tabla_fosa_depth %>% dplyr::filter(fosa_label == "PERU-CHILE TRENCH")
n_intermedia_chile <- fila_chile$Intermedia
n_total_chile <- fila_chile$Intermedia + fila_chile$`Poco profunda` + fila_chile$Profunda

resultados_z_intermedia <- purrr::map_dfr(fosas_japon, function(f) {
  fila <- tabla_fosa_depth %>% dplyr::filter(fosa_label == f)
  n_int_f <- fila$Intermedia
  n_tot_f <- fila$Intermedia + fila$`Poco profunda` + fila$Profunda
  test <- prop.test(x = c(n_intermedia_chile, n_int_f), n = c(n_total_chile, n_tot_f))
  data.frame(fosa = f, prop_intermedia_chile = round(n_intermedia_chile / n_total_chile, 4),
             prop_intermedia_fosa = round(n_int_f / n_tot_f, 4),
             estadistico = round(unname(test$statistic), 3), p_valor = signif(test$p.value, 4))
})
print(resultados_z_intermedia)

# ================================================================================
# B.27 REGRESIÓN LOGÍSTICA: P(evento generador con Mw > 6.5) en función de
#      profundidad, longitud, latitud y número de réplicas, por país
# ================================================================================

logit_chile <- res_chile$datos %>% dplyr::mutate(es_fuerte = as.numeric(transMw > 6.5))
modelo_logit_chile <- glm(es_fuerte ~ depth + longitude + latitude + n_replicas,
                           data = logit_chile, family = binomial(link = "logit"))
summary(modelo_logit_chile)

logit_japon <- res_japon$datos %>% dplyr::mutate(es_fuerte = as.numeric(transMw > 6.5))
modelo_logit_japon <- glm(es_fuerte ~ depth + longitude + latitude + n_replicas,
                           data = logit_japon, family = binomial(link = "logit"))
summary(modelo_logit_japon)

# ================================================================================
# B.28 MAPA COMPLEMENTARIO: generadores de Japón por magnitud, profundidad y
#      banda de latitud (apoya visualmente la regresión logística de B.27)
# ================================================================================

japon_todos_geo <- res_japon$datos %>%
  dplyr::mutate(
    depth_cat = dplyr::case_when(depth < 70 ~ "Poco profunda", depth >= 70 & depth < 300 ~ "Intermedia",
                                  depth >= 300 & depth <= 700 ~ "Profunda", TRUE ~ NA_character_),
    depth_cat = factor(depth_cat, levels = c("Poco profunda", "Intermedia", "Profunda")),
    categoria_mw = factor(ifelse(transMw > 6.5, "Mw > 6,5", "Mw ≤ 6,5"), levels = c("Mw ≤ 6,5", "Mw > 6,5")),
    banda_latitud = cut(latitude, breaks = c(20, 30, 40, 50),
                         labels = c("Sur (20°-30°N)", "Centro (30°-40°N)", "Norte (40°-50°N)"))
  ) %>%
  dplyr::filter(!is.na(depth_cat), !is.na(banda_latitud)) %>%
  dplyr::arrange(categoria_mw)  # dibuja Mw>6,5 al final, para que quede visible encima

xlims_japon <- c(120, 148); ylims_japon <- c(20, 50)

grafico_japon_facet <- ggplot() +
  geom_sf(data = world, fill = "grey90", color = "grey40", linewidth = 0.2) +
  geom_point(data = japon_todos_geo,
             aes(x = longitude, y = latitude, shape = depth_cat, color = categoria_mw),
             size = 3, stroke = 1, alpha = 0.8) +
  coord_sf(xlim = xlims_japon, ylim = ylims_japon, expand = FALSE) +
  scale_shape_manual(values = c("Poco profunda" = 16, "Intermedia" = 17, "Profunda" = 15), name = "Profundidad") +
  scale_color_manual(values = c("Mw ≤ 6,5" = "grey65", "Mw > 6,5" = "#619CFF"), name = "Magnitud") +
  facet_wrap(~ banda_latitud, ncol = 3) +
  labs(title = "Eventos generadores de Japón por magnitud y profundidad", subtitle = "Divididos por banda de latitud",
       x = "Longitud", y = "Latitud") +
  theme_minimal() +
  theme(plot.title = element_text(size = 18, face = "bold", hjust = 0.5), plot.subtitle = element_text(size = 13, hjust = 0.5),
        axis.title = element_text(size = 16, face = "bold"), axis.text = element_text(size = 9),
        legend.title = element_text(size = 16, face = "bold"), legend.text = element_text(size = 14),
        strip.text = element_text(size = 13, face = "bold"), panel.grid.major = element_line(colour = "grey80", linewidth = 0.3))

print(grafico_japon_facet)
ggsave("japon_geo_facet_comparado.png", grafico_japon_facet, width = 12, height = 6, dpi = 300)

# ================================================================================
# B.29 SERIES TEMPORALES DE FONDO: descomposición, ADF, ACF/PACF, Ljung-Box
# ================================================================================

conteo_mensual <- function(datos) {
  datos %>%
    dplyr::mutate(anio = lubridate::year(time), mes = lubridate::month(time)) %>%
    dplyr::count(anio, mes) %>%
    tidyr::complete(anio = 2000:2025, mes = 1:12, fill = list(n = 0)) %>%
    dplyr::arrange(anio, mes)
}

mensual_chile <- conteo_mensual(fondo_chile) %>% dplyr::mutate(pais = "Chile")
mensual_japon <- conteo_mensual(fondo_japon) %>% dplyr::mutate(pais = "Japón")
mensual_todos <- dplyr::bind_rows(mensual_chile, mensual_japon) %>%
  dplyr::mutate(fecha = as.Date(paste(anio, mes, "01", sep = "-")))

ts_chile <- ts(mensual_chile$n, start = c(2000, 1), frequency = 12)
ts_japon <- ts(mensual_japon$n, start = c(2000, 1), frequency = 12)

print(
  ggplot(mensual_todos, aes(x = fecha, y = n, color = pais)) +
    geom_line(linewidth = 0.6) +
    scale_color_manual(values = paleta_pais) +
    labs(title = "Serie mensual de eventos de fondo sísmico", subtitle = "Chile y Japón, 2000-2025",
         x = "Año", y = "N° de eventos de fondo", color = "País") +
    tema_base_decl
)

# --- Descomposición aditiva (nivel, tendencia, estacionalidad, residuo) ---
decomp_chile <- decompose(ts_chile, type = "additive")
decomp_japon <- decompose(ts_japon, type = "additive")
plot(decomp_chile); plot(decomp_japon)

# --- Dickey-Fuller aumentado (estacionariedad) ---
adf.test(ts_chile)
adf.test(ts_japon)

# --- ACF y PACF ---
par(mfrow = c(2, 2))
acf(ts_chile, main = "ACF - Chile"); pacf(ts_chile, main = "PACF - Chile")
acf(ts_japon, main = "ACF - Japón"); pacf(ts_japon, main = "PACF - Japón")
par(mfrow = c(1, 1))  # resetear layout para gráficos posteriores

# --- Ljung-Box, primeros 12 rezagos ---
ljung_box_12 <- function(serie, pais) {
  purrr::map_dfr(1:12, function(k) {
    test <- Box.test(serie, lag = k, type = "Ljung-Box")
    data.frame(pais = pais, rezago = k, p_valor = test$p.value)
  })
}

lb_chile <- ljung_box_12(ts_chile, "Chile")
lb_japon <- ljung_box_12(ts_japon, "Japón")
lb_todos <- dplyr::bind_rows(lb_chile, lb_japon)
print(lb_todos)

print(
  ggplot(lb_todos, aes(x = rezago, y = p_valor, color = pais)) +
    geom_point(size = 2.5) + geom_line() +
    geom_hline(yintercept = 0.05, linetype = "dashed", color = "grey40") +
    scale_x_continuous(breaks = 1:12) +
    scale_color_manual(values = paleta_pais) +
    labs(title = "P-valores del test de Ljung-Box, primeros 12 rezagos", x = "Rezago (meses)", y = "P-valor", color = "País") +
    tema_base_decl
)

# ================================================================================
# B.30 ANÁLISIS DISTRIBUCIONAL INFERENCIAL (Sección 6.6 del informe): KS, CvM,
#      AD, Mann-Whitney y Siegel-Tukey, para magnitud y profundidad
# ================================================================================

# Función Siegel-Tukey (test de dispersión basado en el recorrido clásico de
# rangos: 1 desde abajo, luego bloques de 2 alternando arriba/abajo hacia el
# centro). Distinta de siegel_tukey_centrado() (B.20.6): esta NO centra por
# la mediana de cada grupo antes de rankear — es la versión "genérica" usada
# acá para la batería de 5 tests de magnitud/profundidad.
siegel_tukey <- function(x, y) {
  datos_st <- c(x, y)
  grupo <- c(rep("g1", length(x)), rep("g2", length(y)))
  n <- length(datos_st)
  orden <- order(datos_st)
  datos_ord <- datos_st[orden]

  lo <- 1; hi <- n
  secuencia <- integer(n)
  k <- 1
  secuencia[k] <- lo; lo <- lo + 1; k <- k + 1
  lado <- "hi"
  while (lo <= hi) {
    tomar <- min(2, hi - lo + 1)
    for (i in seq_len(tomar)) {
      if (lado == "hi") { secuencia[k] <- hi; hi <- hi - 1 } else { secuencia[k] <- lo; lo <- lo + 1 }
      k <- k + 1
    }
    lado <- ifelse(lado == "hi", "lo", "hi")
  }

  rango_st_ordenado <- integer(n)
  rango_st_ordenado[secuencia] <- 1:n
  rango_st_ordenado <- ave(rango_st_ordenado, datos_ord, FUN = mean)  # promedia empates

  rango_st <- numeric(n)
  rango_st[orden] <- rango_st_ordenado

  wilcox.test(rango_st[grupo == "g1"], rango_st[grupo == "g2"])
}

# Función maestra: arma una fila de comparación con los 5 tests
comparar_distribuciones <- function(chile_x, japon_x, etiqueta = "") {
  chile_x <- chile_x[!is.na(chile_x)]
  japon_x <- japon_x[!is.na(japon_x)]

  ks  <- ks.test(chile_x, japon_x, exact = FALSE)
  cvm <- cvm_test(chile_x, japon_x)
  ad  <- ad_test(chile_x, japon_x)
  mw  <- wilcox.test(chile_x, japon_x)
  st  <- siegel_tukey(chile_x, japon_x)

  tibble(
    comparacion = etiqueta, n_chile = length(chile_x), n_japon = length(japon_x),
    KS_stat = unname(ks$statistic), KS_p = ks$p.value,
    CvM_stat = unname(cvm["Test Stat"]), CvM_p = unname(cvm["P-Value"]),
    AD_stat = unname(ad["Test Stat"]), AD_p = unname(ad["P-Value"]),
    MW_stat = unname(mw$statistic), MW_p = mw$p.value,
    ST_stat = unname(st$statistic), ST_p = st$p.value
  )
}

# --- Comparación de Magnitud de Momento (transMw) ---
tabla_magnitud <- bind_rows(
  comparar_distribuciones(fondo_chile$transMw, fondo_japon$transMw, "General"),
  comparar_distribuciones(fondo_chile$transMw[fondo_chile$depth_cat == "Poco profunda"],
                           fondo_japon$transMw[fondo_japon$depth_cat == "Poco profunda"], "Poco profunda"),
  comparar_distribuciones(fondo_chile$transMw[fondo_chile$depth_cat == "Intermedia"],
                           fondo_japon$transMw[fondo_japon$depth_cat == "Intermedia"], "Intermedia")
)

# --- Comparación de Profundidad (depth) ---
tabla_profundidad <- bind_rows(
  comparar_distribuciones(fondo_chile$depth, fondo_japon$depth, "General"),
  comparar_distribuciones(fondo_chile$depth[fondo_chile$Mw_cat == "Moderate"],
                           fondo_japon$depth[fondo_japon$Mw_cat == "Moderate"], "Moderate"),
  comparar_distribuciones(fondo_chile$depth[fondo_chile$Mw_cat == "Strong"],
                           fondo_japon$depth[fondo_japon$Mw_cat == "Strong"], "Strong"),
  comparar_distribuciones(fondo_chile$depth[fondo_chile$Mw_cat == "Major"],
                           fondo_japon$depth[fondo_japon$Mw_cat == "Major"], "Major")
)

print(tabla_magnitud %>% mutate(across(where(is.numeric) & !c(n_chile, n_japon), ~round(.x, 4))) %>%
        knitr::kable(digits = 4, caption = "Comparación distribucional de Mw entre Chile y Japón"))
print(tabla_profundidad %>% mutate(across(where(is.numeric) & !c(n_chile, n_japon), ~round(.x, 4))) %>%
        knitr::kable(digits = 4, caption = "Comparación distribucional de profundidad entre Chile y Japón"))

# --- ECDF de apoyo visual para ambas comparaciones ---
construir_df_ecdf <- function(var_chile, var_japon, etiqueta) {
  tibble(valor = c(var_chile, var_japon), pais = c(rep("Chile", length(var_chile)), rep("Japón", length(var_japon))), subgrupo = etiqueta)
}

df_ecdf_mag <- bind_rows(
  construir_df_ecdf(fondo_chile$transMw, fondo_japon$transMw, "General"),
  construir_df_ecdf(fondo_chile$transMw[fondo_chile$depth_cat == "Poco profunda"], fondo_japon$transMw[fondo_japon$depth_cat == "Poco profunda"], "Poco profunda"),
  construir_df_ecdf(fondo_chile$transMw[fondo_chile$depth_cat == "Intermedia"], fondo_japon$transMw[fondo_japon$depth_cat == "Intermedia"], "Intermedia")
) %>% mutate(subgrupo = factor(subgrupo, levels = c("General", "Poco profunda", "Intermedia")))

print(
  ggplot(df_ecdf_mag, aes(x = valor, color = pais)) +
    stat_ecdf(linewidth = 0.8) + facet_wrap(~ subgrupo, ncol = 3) +
    scale_color_manual(values = paleta_pais) +
    labs(title = "Funciones de distribución empírica (ECDF) de la Magnitud de Momento",
         subtitle = "Chile vs Japón — general y por categoría de profundidad", x = expression(M[w]), y = "F(x)", color = "País") +
    tema_base_decl
)

df_ecdf_prof <- bind_rows(
  construir_df_ecdf(fondo_chile$depth, fondo_japon$depth, "General"),
  construir_df_ecdf(fondo_chile$depth[fondo_chile$Mw_cat == "Moderate"], fondo_japon$depth[fondo_japon$Mw_cat == "Moderate"], "Moderate"),
  construir_df_ecdf(fondo_chile$depth[fondo_chile$Mw_cat == "Strong"], fondo_japon$depth[fondo_japon$Mw_cat == "Strong"], "Strong")
) %>% mutate(subgrupo = factor(subgrupo, levels = c("General", "Moderate", "Strong")))

print(
  ggplot(df_ecdf_prof, aes(x = valor, color = pais)) +
    stat_ecdf(linewidth = 0.8) + facet_wrap(~ subgrupo, ncol = 3, scales = "free_x") +
    scale_color_manual(values = paleta_pais) +
    labs(title = "Funciones de distribución empírica (ECDF) de la Profundidad",
         subtitle = "Chile vs Japón — general y por categoría de magnitud", x = "Profundidad (km)", y = "F(x)", color = "País") +
    tema_base_decl
)

# ================================================================================
# B.31 PRODUCTIVIDAD DE RÉPLICAS: correlación y modelo Binomial Negativa (6.7)
# ================================================================================

# Correlación de Spearman: robusta a la asimetría/sobredispersión de
# n_replicas, evalúa relación monótona (no exige linealidad ni normalidad)
cor_chile <- cor.test(res_chile$datos$transMw, res_chile$datos$n_replicas, method = "spearman")
cor_japon <- cor.test(res_japon$datos$transMw, res_japon$datos$n_replicas, method = "spearman")
cor_chile; cor_japon

# Modelo de productividad: Binomial Negativa (consistente con la
# sobredispersión ya documentada de n_replicas), cuantifica la relación de
# forma paramétrica — corresponde al Cuadro 37 del informe.
modelo_prod_chile <- glm.nb(n_replicas ~ transMw, data = res_chile$datos)
modelo_prod_japon <- glm.nb(n_replicas ~ transMw, data = res_japon$datos)
summary(modelo_prod_chile); summary(modelo_prod_japon)

# Tasa de incremento esperado en n° de réplicas por unidad de magnitud
exp(coef(modelo_prod_chile)["transMw"])
exp(coef(modelo_prod_japon)["transMw"])

df_productividad <- dplyr::bind_rows(
  res_chile$datos %>% dplyr::select(transMw, n_replicas) %>% dplyr::mutate(pais = "Chile"),
  res_japon$datos %>% dplyr::select(transMw, n_replicas) %>% dplyr::mutate(pais = "Japón")
)

print(
  ggplot(df_productividad, aes(x = transMw, y = n_replicas + 1, color = pais)) +
    geom_point(alpha = 0.4, size = 1.5) +
    geom_smooth(method = "loess", se = TRUE) +
    scale_y_log10() +
    scale_color_manual(values = paleta_pais) +
    labs(title = "Productividad de réplicas según magnitud del sismo generador",
         x = expression(M[w]~"del generador"), y = "N° de réplicas + 1 (escala log)", color = "País") +
    tema_base_decl
)

# --- Verificación del supuesto de equidispersión antes de ajustar el modelo
#     de productividad (Binomial Negativa): media vs. varianza de n_replicas.
#     Se agrega indice_dispersion = varianza/media (ausente en el script
#     original: la llamada final a mutate() referenciaba esta columna sin
#     haberla calculado antes, lo que habría hecho fallar el script en este
#     punto con "object 'indice_dispersion' not found"). Un índice >> 1
#     confirma sobredispersión y justifica usar Binomial Negativa en vez de
#     Poisson para modelar n_replicas.
estadisticas_replicas <- bind_rows(
  res_chile$datos %>% summarise(pais = "Chile", n = n(), media = mean(n_replicas), varianza = var(n_replicas),
                                 minimo = min(n_replicas), maximo = max(n_replicas)),
  res_japon$datos %>% summarise(pais = "Japón", n = n(), media = mean(n_replicas), varianza = var(n_replicas),
                                 minimo = min(n_replicas), maximo = max(n_replicas))
) %>%
  dplyr::mutate(indice_dispersion = varianza / media)

print(estadisticas_replicas)

media_var_chile <- c(media = mean(res_chile$datos$n_replicas), varianza = var(res_chile$datos$n_replicas))
media_var_japon <- c(media = mean(res_japon$datos$n_replicas), varianza = var(res_japon$datos$n_replicas))
media_var_chile; media_var_japon

estadisticas_replicas <- estadisticas_replicas %>%
  dplyr::mutate(dplyr::across(c(media, varianza, indice_dispersion), ~round(.x, 2)))
options(pillar.sigfig = 6)
print(estadisticas_replicas)

# FIN PARTE B / FIN DEL SCRIPT ===================================================
