# Sismicidad Chile-Japón (2000-2025): análisis descriptivo y declustering

Código en R del Taller I / Ingeniería Estadística (USACH), Asesorías I y II —
Grupo Lambda Analytics. Compara la sismicidad de Chile y Japón (catálogo
USGS, 2000-2025): análisis descriptivo (Asesoría I) y declustering
espacio-temporal-magnitud según Zaliapin & Ben-Zion (2020), vecino más
cercano (Asesoría II).

Este repositorio contiene dos scripts:

- **`codigo_asesoria2_completo.R`** — fusiona ambas asesorías (descriptiva +
  declustering ZBZ) en un pipeline reproducible de principio a fin.
- **`validacion_cruzada_gardner_knopoff.R`** — aplica un segundo método de
  declustering (Gardner & Knopoff, 1974) sobre el mismo catálogo y compara
  sus resultados contra los de ZBZ, a modo de validación cruzada. Ver
  [Validación cruzada](#validación-cruzada-gardner-knopoff) abajo.

Ambos reutilizan la misma carpeta `data/`, que trae todo lo necesario para
correr — ver [Datos](#datos) abajo.

## Cómo correrlo

1. Instala los paquetes de R requeridos:
   ```r
   source("install_packages.R")
   ```
2. Abre esta carpeta como proyecto/carpeta de trabajo en RStudio (o corre
   `setwd("ruta/a/asesoria2-sismicidad-chile-japon")` antes de lo siguiente),
   para que las rutas relativas a `data/` funcionen.
3. Corre el script **completo, de principio a fin, en una sola pasada** —
   con el botón "Source" de RStudio (`Ctrl+Shift+Enter` / `Cmd+Shift+Enter`),
   o desde la consola:
   ```r
   source("codigo_asesoria2_completo.R")
   ```
   No lo corras por fragmentos/selecciones sueltas: varias secciones
   posteriores dependen de objetos que se crean en secciones anteriores, y
   la Parte B depende de que la semilla (`set.seed(2026)`, sección 1.2) se
   consuma en el orden exacto en que aparece el código.

⏱️ **El script completo tarda varios minutos** (no es instantáneo aunque
tengas una máquina potente): hace cálculos de vecino-más-cercano O(n²) sobre
miles de sismos, tests de permutación, una batería de 50 realizaciones ×
grilla de parámetros para la robustez del umbral de declustering, y decenas
de gráficos. Esto es esperado, no un error.

## Datos

Todo lo que el script necesita ya está incluido en la carpeta `data/` —
el repositorio queda 100% autocontenido, no hace falta descargar ni copiar
nada más:

| Archivo | Descripción |
|---|---|
| `data/Chile00-25.csv`, `data/Japon00-25.csv` | Catálogo USGS 2000-2025, usado en la Parte A (descriptiva) |
| `data/Chile90-25.csv`, `data/Japon90-25.csv` | Catálogo USGS 1990-2025 (incluye colchón pre-2000), usado en la Parte B (declustering) |
| `data/chile_declusterizado_completo_con_colchon.csv`, `data/japon_declusterizado_completo_con_colchon.csv` | Catálogos ya declusterizados (salida de una corrida previa), usados por `MODO_REPRODUCCION_INFORME` — ver abajo |
| `data/PLATES_PlateBoundary_ArcGIS/trench.shp` (+ `.dbf`/`.shx`/`.prj`) | Shapefile de fosas oceánicas (Plate Boundary dataset), usado en la Sección A.2 en adelante y en B.26 |

Si en algún momento mueves o renombras esta carpeta, el script sigue
buscando `data/PLATES_PlateBoundary_ArcGIS/trench.shp` de forma relativa
(Sección 1.1) — y si por algún motivo faltara, se detiene con un mensaje
claro en vez de un error críptico de GDAL, indicando exactamente qué
archivo espera y dónde.

### Modo reproducción del informe

El script tiene un interruptor, `MODO_REPRODUCCION_INFORME` (sección 1.1.1),
pensado para reproducir EXACTAMENTE los números ya publicados en el informe
en vez de volver a sortear el paso estocástico del declustering (que no
queda perfectamente fijado solo con `set.seed()`, ver comentario en el
código, sección B.8):

- **`TRUE`** (valor por defecto): carga los catálogos ya declusterizados de
  `data/` en vez de recalcular el declustering. Ya vienen incluidos en este
  repositorio, así que esto funciona de inmediato.
- **`FALSE`**: corre el declustering desde cero (`declustering_zbz()`),
  útil si vas a generar resultados nuevos sobre datos actualizados, no para
  reproducir el informe ya entregado.

## Estructura del script

- **Parte A** — análisis descriptivo (mapas, distribuciones de magnitud y
  profundidad, series de tiempo, curvas de Lorenz, asociación
  magnitud-profundidad).
- **Parte B** — declustering Zaliapin & Ben-Zion (2020): estimación de
  `eta`/`eta0` (mezcla de 2 gaussianas), thinning probabilístico
  fondo/réplica, reasignación del "generador" de cada familia al evento de
  mayor magnitud (no la raíz temporal/algorítmica — ver sección B.8.1),
  batería de validación (KS, test de puente Browniano, Luen-Stark),
  productividad de réplicas vs. magnitud, y modelos de regresión
  (binomial negativa, logística) sobre la ocurrencia de eventos grandes.

## Validación cruzada Gardner-Knopoff

`validacion_cruzada_gardner_knopoff.R` corre independientemente sobre el
catálogo crudo (`data/Chile00-25.csv` / `data/Japon00-25.csv`, limpiado con
las mismas reglas que Asesoria_I.R) el método de ventana espacio-temporal de
**Gardner & Knopoff (1974)**, reparametrizado según **Uhrhammer (1986)**, y
compara evento por evento su clasificación fondo/réplica contra la de ZBZ
(cargada desde los catálogos congelados de `data/`). No requiere volver a
correr `codigo_asesoria2_completo.R` primero.

Resultados de referencia (ya verificados, deberían reproducirse al correr
el script):

| | Chile | Japón |
|---|---|---|
| % independiente (fondo) según GK | 30.96% | 31.43% |
| % fondo según ZBZ (ref.) | 34.05% | 33.89% |
| Acuerdo simple (evento por evento) | 74.0% | 76.5% |
| Kappa de Cohen | 0.408 (moderado) | 0.467 (moderado) |

El hallazgo más interesante de la comparación: ambos métodos coinciden
bastante bien en familias medianas (p.ej. la familia chilena de 2006, M6.7,
21/22 réplicas quedan con el mismo generador bajo ambos métodos), pero
**Gardner-Knopoff fragmenta fuertemente las secuencias más grandes**: de las
440 réplicas que ZBZ atribuye al Maule 2010 (M8.8), GK solo deja 124 bajo el
mismo generador, repartiendo el resto en 34 familias GK distintas; para
Tohoku 2011 (M9.1, 807 réplicas según ZBZ), GK retiene solo 283 y fragmenta
el resto en 59 familias. Esto es consistente con una limitación conocida y
documentada de Gardner-Knopoff (no encadena "réplicas de réplicas": una
réplica lo bastante grande se vuelve su propio generador) — es justamente
el problema que Zaliapin & Ben-Zion (2020) señalan como motivación para el
método de vecino-más-cercano usado en el resto de este repositorio.

Archivos que exporta: `chile_gardner_knopoff.csv`, `japon_gardner_knopoff.csv`
(catálogo completo con la clasificación GK), `chile_generadores_gk.csv`,
`japon_generadores_gk.csv` (tabla de productividad por generador, análoga a
`chile_generadores.csv`/`japon_generadores.csv` de ZBZ), y
`comparacion_familias_grandes_zbz_vs_gk.csv` (la tabla de fragmentación).

## Reproducibilidad

- Semilla única: `set.seed(2026)` (sección 1.2), consumida en orden desde
  el inicio del script hasta el final — no se reinicia en ningún punto
  intermedio (ver advertencia en sección B.8 sobre por qué reiniciarla ahí
  rompe la reproducibilidad).
- `RNGkind(kind = "Mersenne-Twister", normal.kind = "Inversion", sample.kind
  = "Rejection")` fijado explícitamente (sección 1.2) para blindar contra
  diferencias de versión de R (el algoritmo por defecto de `sample()`
  cambió en R 3.6.0).
- Versión de R usada en desarrollo: ver `install_packages.R` (imprime
  `R.version.string` al final).

## Referencias

- Zaliapin, I., & Ben-Zion, Y. (2020). *Earthquake declustering using the
  nearest-neighbor approach in space-time-magnitude domain*.
- Gardner, J. K., & Knopoff, L. (1974). *Is the sequence of earthquakes in
  Southern California, with aftershocks removed, Poissonian?* Bulletin of
  the Seismological Society of America, 64(5), 1363-1367.
- Uhrhammer, R. A. (1986). *Characteristics of northern and central
  California seismicity*. Earthquake Notes, 57(1), 21.
- Teng, G., & Baker, J. W. (2019). *Seismicity declustering and hazard
  analysis of the Oklahoma-Kansas region*. Bulletin of the Seismological
  Society of America, 109(6), 2356-2366.
