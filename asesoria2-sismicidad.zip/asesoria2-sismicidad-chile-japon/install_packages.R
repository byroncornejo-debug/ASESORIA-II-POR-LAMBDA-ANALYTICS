# ==============================================================================
# install_packages.R
#
# Instala todos los paquetes de R que requieren codigo_asesoria2_completo.R
# y validacion_cruzada_gardner_knopoff.R. Basta con correr este archivo UNA
# VEZ (o cada vez que cambies de máquina/R limpio) antes de correr
# cualquiera de los dos scripts.
#
# Uso:
#   Rscript install_packages.R
# o, desde la consola de R / RStudio:
#   source("install_packages.R")
# ==============================================================================

paquetes_requeridos <- c(
  "MASS",         # glm.nb() (Binomial Negativa)
  "lubridate",    # manejo de fechas
  "dplyr",        # manipulación de datos
  "stringr",      # str_detect() para filtrar por país
  "ggplot2",      # gráficos
  "sf",           # geometrías espaciales (fosas, mapas)
  "rnaturalearth",# polígonos de países para mapas
  "ineq",         # curvas de Lorenz
  "tidyr",        # pivot_longer/pivot_wider, complete()
  "readr",        # read_csv() / write_csv()
  "ggridges",     # gráficos ridgeline
  "mclust",       # mezcla de 2 gaussianas (estimación de eta0)
  "patchwork",    # combinar paneles de ggplot
  "DescTools",    # SiegelTukeyTest()
  "KScorrect",    # LcKS() bondad de ajuste exponencial
  "tseries",      # adf.test()
  "purrr",        # map_dfr()
  "twosamples",   # cvm_test(), ad_test()
  "tibble",       # utilidades de tibble
  "scales",       # formato de ejes en gráficos
  "knitr",        # kable() para tablas del informe
  "geosphere"     # distHaversine() (validacion_cruzada_gardner_knopoff.R)
)

faltantes <- paquetes_requeridos[!paquetes_requeridos %in% rownames(installed.packages())]

if (length(faltantes) > 0) {
  cat("Instalando paquetes faltantes:", paste(faltantes, collapse = ", "), "\n")
  install.packages(faltantes, dependencies = TRUE)
} else {
  cat("Todos los paquetes requeridos ya están instalados.\n")
}

cat("\nVersión de R usada para desarrollar el script:\n")
cat(R.version.string, "\n")
