# ==============================================================================
# VALIDACIÓN CRUZADA: DECLUSTERING GARDNER-KNOPOFF (1974) vs. ZALIAPIN-BEN-ZION
#
# Este script es un COMPLEMENTO a codigo_asesoria2_completo.R, no un
# reemplazo. Aplica un segundo método de declustering -Gardner & Knopoff
# (1974), el método de "ventana" espacio-temporal más clásico y citado en
# sismología- de forma independiente sobre el mismo catálogo crudo, y
# compara sus resultados contra los del método de vecino-más-cercano
# (Zaliapin & Ben-Zion 2020) ya usado en el resto del informe. El objetivo
# es una validación cruzada: ¿coinciden ambos métodos en qué eventos son
# "sismicidad de fondo" y cuáles son réplicas? ¿coinciden en cuál es el
# sismo de mayor magnitud (generador) de cada gran familia sísmica?
#
# La carga y limpieza de datos de la Sección 1 está basada directamente en
# Asesoria_I.R (mismas reglas de filtrado por país/magType y misma fórmula
# de homogeneización a Mw), para partir del mismo catálogo base que el
# resto del proyecto.
#
# Requiere: dplyr, lubridate, stringr, readr, geosphere, ggplot2
# (instala lo que falte con install.packages(c("dplyr","lubridate",
# "stringr","readr","geosphere","ggplot2")))
# ==============================================================================

library(dplyr)
library(lubridate)
library(stringr)
library(readr)
library(geosphere)  # distHaversine(): distancia geodésica entre dos puntos lat/lon
library(ggplot2)

# Reasignación defensiva por si algún otro paquete cargado más tarde
# enmascara estas funciones de dplyr (mismo problema que ya se documentó en
# codigo_asesoria2_completo.R, Sección 0).
select    <- dplyr::select
filter    <- dplyr::filter
count     <- dplyr::count
rename    <- dplyr::rename
summarise <- dplyr::summarise
mutate    <- dplyr::mutate
arrange   <- dplyr::arrange
group_by  <- dplyr::group_by

# Misma carpeta de datos que usa codigo_asesoria2_completo.R -este script
# está pensado para vivir en la misma carpeta del repositorio y reutilizar
# los mismos archivos de data/ (catálogos crudos + catálogos ZBZ ya
# congelados), sin tener que descargar ni copiar nada aparte.
RUTA_DATOS <- "data/"

RUTA_CHILE_00_25        <- paste0(RUTA_DATOS, "Chile00-25.csv")
RUTA_JAPON_00_25        <- paste0(RUTA_DATOS, "Japon00-25.csv")
RUTA_CHILE_DECL_COLCHON <- paste0(RUTA_DATOS, "chile_declusterizado_completo_con_colchon.csv")
RUTA_JAPON_DECL_COLCHON <- paste0(RUTA_DATOS, "japon_declusterizado_completo_con_colchon.csv")

# ==============================================================================
# 1. CARGA Y LIMPIEZA DEL CATÁLOGO CRUDO (idéntico a Asesoria_I.R, Sección 3)
#
#    Se usa el catálogo 2000-2025 (sin colchón pre-2000): Gardner-Knopoff no
#    necesita candidatos a padre fuera del período de estudio de la misma
#    forma en que los necesita el cálculo de eta/alpha de ZBZ (Sección B.8
#    de codigo_asesoria2_completo.R) -su ventana espacio-temporal depende
#    solo de la magnitud del propio evento, no de vecinos previos-, así que
#    basta con el catálogo del período de estudio. Esto es una diferencia
#    metodológica menor entre ambos métodos que vale la pena mencionar en el
#    informe si se discuten posibles sesgos de borde.
# ==============================================================================

cargar_y_limpiar <- function(path_csv, pais) {
  raw <- read_csv(path_csv, show_col_types = FALSE) %>% mutate(Pais = pais)
  raw %>%
    filter(
      if (pais == "Chile") {
        str_detect(place, "Chile") & !str_detect(place, "Argentina")
      } else {
        str_detect(place, "Japan")
      },
      !(magType %in% c("m", "ml"))
    ) %>%
    mutate(
      transMw = case_when(
        magType %in% c("mw", "mwb", "mwc", "mwr", "mww") ~ mag,
        magType == "ms" & mag >= 3.0 & mag <= 6.1 ~ 0.67 * mag + 2.07,
        magType == "ms" & mag >= 6.2 & mag <= 8.2 ~ 0.99 * mag + 0.08,
        magType == "mb" & mag >= 3.5 & mag <= 6.7 ~ 0.85 * mag + 1.03,
        TRUE ~ NA_real_
      )
    ) %>%
    filter(!is.na(transMw)) %>%
    arrange(time)
}

chile_datos <- cargar_y_limpiar(RUTA_CHILE_00_25, "Chile")
japon_datos <- cargar_y_limpiar(RUTA_JAPON_00_25, "Japón")

cat("N Chile (2000-2025, post-limpieza):", nrow(chile_datos), "\n")
cat("N Japón (2000-2025, post-limpieza):", nrow(japon_datos), "\n")

# ==============================================================================
# 2. VENTANAS ESPACIO-TEMPORALES DE GARDNER & KNOPOFF (1974)
#
#    Se usa la reparametrización continua de Uhrhammer (1986) de la tabla
#    original de Gardner & Knopoff (1974), que es la versión estándar
#    implementada en software de sismicidad (p.ej. OpenQuake HMTK, ZMAP) y
#    en revisiones metodológicas como van Stiphout et al. (2012, CORSSA) y
#    Teng & Baker (2019, BSSA):
#
#      Ventana espacial:  log10(L) = 0.1238*M + 0.983        (L en km)
#      Ventana temporal:  log10(T) = 0.032*M  + 2.7389        (T en días, M >= 6.5)
#                          log10(T) = 0.5409*M - 0.547         (T en días, M <  6.5)
#
#    Un evento posterior a un sismo de magnitud M se considera dependiente
#    de él (réplica) si cae dentro de L(M) km Y dentro de T(M) días
#    siguientes. fs_time_prop controla cuánto de esa misma ventana temporal
#    se usa hacia ATRÁS para capturar precursores/foreshocks (1.0 = ventana
#    simétrica completa hacia atrás y adelante; 0 = ignora precursores). Se
#    deja en 1.0 acá como valor por defecto simple y documentado -ajústalo
#    si quieres replicar exactamente la convención de algún software
#    específico.
# ==============================================================================

ventanas_gk <- function(M) {
  L <- 10^(0.1238 * M + 0.983)
  T <- ifelse(M >= 6.5, 10^(0.032 * M + 2.7389), 10^(0.5409 * M - 0.547))
  list(L = L, T = T)
}

# ==============================================================================
# 3. ALGORITMO DE VENTANA DE GARDNER-KNOPOFF
#
#    Procesa los eventos de mayor a menor magnitud. Para cada evento aún no
#    "reclamado" por un sismo más grande, se calcula su propia ventana
#    espacio-temporal (Sección 2) y se buscan TODOS los demás eventos
#    (de cualquier magnitud) que caigan dentro de esa ventana y que no
#    hayan sido ya reclamados por un evento todavía más grande -esos quedan
#    marcados como réplicas/precursores de él ("reclamados"). Al terminar,
#    los eventos nunca reclamados por nadie son la sismicidad "independiente"
#    (de fondo) según este método -exactamente análogo a es_fondo en ZBZ.
#
#    LIMITACIÓN CONOCIDA de este método (documentada en la literatura, p.ej.
#    Teng & Baker 2019, y es justamente el motivo por el que Zaliapin &
#    Ben-Zion 2020 proponen el método de vecino-más-cercano en su lugar):
#    Gardner-Knopoff NO encadena "réplicas de réplicas" -si una réplica es
#    lo bastante grande, se convierte en su PROPIO generador con su propia
#    familia separada, en vez de seguir contando como parte de la secuencia
#    original. Esto fragmenta secuencias largas y complejas (ver Sección 7
#    de este script para la comparación concreta en Maule 2010 y Tohoku
#    2011).
# ==============================================================================

gardner_knopoff <- function(datos, fs_time_prop = 1.0) {
  n <- nrow(datos)
  lat <- datos$latitude
  lon <- datos$longitude
  M   <- datos$transMw
  t_dias <- as.numeric(difftime(datos$time, min(datos$time), units = "days"))

  vent <- ventanas_gk(M)
  L <- vent$L; Tt <- vent$T

  orden <- order(-M)  # índices ordenados de mayor a menor magnitud
  reclamado <- rep(FALSE, n)
  id_generador_idx <- rep(NA_integer_, n)

  for (i in orden) {
    if (reclamado[i]) next

    dt   <- t_dias - t_dias[i]
    dist_km <- distHaversine(cbind(lon, lat), c(lon[i], lat[i])) / 1000

    en_ventana <- (dist_km <= L[i]) & (dt >= -fs_time_prop * Tt[i]) & (dt <= Tt[i])
    en_ventana[i] <- FALSE
    candidatos <- which(en_ventana & !reclamado)

    if (length(candidatos) > 0) {
      reclamado[candidatos] <- TRUE
      id_generador_idx[candidatos] <- i
    }
    if (is.na(id_generador_idx[i])) id_generador_idx[i] <- i  # independiente / mainshock
  }

  datos %>%
    mutate(
      id_generador_gk      = id[id_generador_idx],
      es_independiente_gk  = (id_generador_idx == seq_len(n))
    )
}

cat("\nCorriendo Gardner-Knopoff sobre Chile...\n")
chile_gk <- gardner_knopoff(chile_datos)
cat("Corriendo Gardner-Knopoff sobre Japón...\n")
japon_gk <- gardner_knopoff(japon_datos)

cat(sprintf("\nChile: %d de %d eventos independientes (%.2f%%) según GK\n",
            sum(chile_gk$es_independiente_gk), nrow(chile_gk),
            100 * mean(chile_gk$es_independiente_gk)))
cat(sprintf("Japón: %d de %d eventos independientes (%.2f%%) según GK\n",
            sum(japon_gk$es_independiente_gk), nrow(japon_gk),
            100 * mean(japon_gk$es_independiente_gk)))

# ==============================================================================
# 4. TABLA DE PRODUCTIVIDAD POR GENERADOR (GK) — análoga a tabla_generadores()
#    de codigo_asesoria2_completo.R (Sección B.9), para comparar peras con
#    peras contra el método ZBZ.
# ==============================================================================

tabla_generadores_gk <- function(datos_gk) {
  datos_gk %>%
    filter(!es_independiente_gk) %>%
    count(id_generador_gk, name = "n_replicas_gk") %>%
    left_join(
      datos_gk %>% select(id, transMw, time, latitude, longitude, depth),
      by = c("id_generador_gk" = "id")
    ) %>%
    arrange(desc(n_replicas_gk))
}

gen_chile_gk <- tabla_generadores_gk(chile_gk)
gen_japon_gk <- tabla_generadores_gk(japon_gk)

cat("\nTop 10 generadores Chile (GK):\n"); print(head(gen_chile_gk, 10))
cat("\nTop 10 generadores Japón (GK):\n"); print(head(gen_japon_gk, 10))

# ==============================================================================
# 5. CARGA DE LOS RESULTADOS ZBZ YA CONGELADOS, PARA LA COMPARACIÓN
#
#    Se reutilizan los catálogos declusterizados con colchón que ya trae
#    data/ (los mismos que usa MODO_REPRODUCCION_INFORME en
#    codigo_asesoria2_completo.R), y se les aplica la MISMA reasignación de
#    generador a mayor magnitud (Sección B.8.1 de ese script) para que la
#    comparación sea contra el método ZBZ ya corregido, no contra la raíz
#    temporal/algorítmica sin corregir.
# ==============================================================================

reasignar_generador_mayor_magnitud <- function(datos_decl) {
  datos_decl %>%
    rename(id_familia = id_generador) %>%
    group_by(id_familia) %>%
    mutate(id_generador = id[which.max(transMw)]) %>%
    ungroup()
}

cargar_zbz_congelado <- function(path_colchon) {
  read_csv(path_colchon, col_types = cols(
    id           = col_character(),
    id_padre     = col_character(),
    id_generador = col_character(),
    es_analisis  = col_logical(),
    es_fondo     = col_logical(),
    .default     = col_guess()
  )) %>%
    reasignar_generador_mayor_magnitud() %>%
    filter(es_analisis)
}

chile_zbz <- cargar_zbz_congelado(RUTA_CHILE_DECL_COLCHON)
japon_zbz <- cargar_zbz_congelado(RUTA_JAPON_DECL_COLCHON)

# ==============================================================================
# 6. TABLA DE CONTINGENCIA Y ACUERDO ENTRE MÉTODOS (fondo/independiente)
#
#    Cruza, evento por evento, la clasificación fondo/réplica de ZBZ contra
#    independiente/dependiente de GK. El "acuerdo simple" es el % de
#    eventos donde ambos métodos coinciden; el kappa de Cohen corrige ese
#    acuerdo por el que se esperaría solo por azar (kappa=0 → no mejor que
#    azar; kappa=1 → acuerdo perfecto; 0.4-0.6 se suele leer como acuerdo
#    "moderado" en la escala de Landis & Koch 1977).
# ==============================================================================

comparar_metodos <- function(datos_zbz, datos_gk, pais) {
  comp <- datos_zbz %>%
    select(id, es_fondo_zbz = es_fondo, id_generador_zbz = id_generador) %>%
    inner_join(
      datos_gk %>% select(id, es_independiente_gk, id_generador_gk),
      by = "id"
    )

  tabla_contingencia <- table(
    ZBZ = ifelse(comp$es_fondo_zbz, "Fondo", "Réplica"),
    GK  = ifelse(comp$es_independiente_gk, "Independiente", "Dependiente")
  )

  acuerdo <- mean(comp$es_fondo_zbz == comp$es_independiente_gk)
  p_zbz <- mean(comp$es_fondo_zbz); p_gk <- mean(comp$es_independiente_gk)
  acuerdo_esperado_azar <- p_zbz * p_gk + (1 - p_zbz) * (1 - p_gk)
  kappa <- (acuerdo - acuerdo_esperado_azar) / (1 - acuerdo_esperado_azar)

  cat(sprintf("\n=== %s: tabla de contingencia ZBZ (fondo/réplica) x GK (independiente/dependiente) ===\n", pais))
  print(tabla_contingencia)
  cat(sprintf("Acuerdo simple: %.1f%%   Kappa de Cohen: %.3f\n", 100 * acuerdo, kappa))

  list(comparacion = comp, contingencia = tabla_contingencia, acuerdo = acuerdo, kappa = kappa)
}

comp_chile <- comparar_metodos(chile_zbz, chile_gk, "Chile")
comp_japon <- comparar_metodos(japon_zbz, japon_gk, "Japón")

# ==============================================================================
# 7. LOS SISMOS DE MAYOR INTENSIDAD, POR FAMILIA: ¿COINCIDEN AMBOS MÉTODOS?
#
#    Para cada una de las familias más grandes según ZBZ (los generadores
#    con más réplicas -ej. Maule 2010, Illapel 2015, Tohoku 2011-), se
#    revisa qué le pasó a esa misma familia bajo Gardner-Knopoff: ¿cuántos
#    de sus miembros GK todavía atribuye al mismo generador, y en cuántas
#    familias GK distintas terminó repartida esa secuencia? Un número alto
#    de familias GK distintas para una misma familia ZBZ es evidencia
#    directa de la fragmentación que describe la Sección 3 de este script.
# ==============================================================================

comparar_familias_grandes <- function(comparacion, datos_zbz, pais, top_n = 6) {
  replicas_zbz <- comparacion %>%
    filter(!es_fondo_zbz) %>%
    count(id_generador_zbz, name = "n_replicas_zbz") %>%
    arrange(desc(n_replicas_zbz)) %>%
    head(top_n)

  cat(sprintf("\n=== %s: fragmentación de las familias ZBZ más grandes bajo GK ===\n", pais))
  resultados <- lapply(replicas_zbz$id_generador_zbz, function(gen_id) {
    miembros <- comparacion %>% filter(id_generador_zbz == gen_id)
    info_generador <- datos_zbz %>% filter(id == gen_id) %>% select(time, transMw)
    n_mismo_generador_gk <- sum(miembros$id_generador_gk == gen_id)
    n_familias_gk         <- n_distinct(miembros$id_generador_gk)

    cat(sprintf(
      "- %s  Mw=%.1f  n_replicas_ZBZ=%d  | bajo GK: %d de %d eventos siguen con el mismo generador, repartidos en %d familias GK distintas\n",
      info_generador$time, info_generador$transMw, nrow(miembros) - 1,
      n_mismo_generador_gk, nrow(miembros), n_familias_gk
    ))

    data.frame(
      Pais = pais, id_generador = gen_id, time = info_generador$time, transMw = info_generador$transMw,
      n_replicas_zbz = nrow(miembros) - 1, n_mismo_generador_gk = n_mismo_generador_gk,
      pct_retenido_gk = round(100 * n_mismo_generador_gk / nrow(miembros), 1),
      n_familias_gk = n_familias_gk
    )
  })
  bind_rows(resultados)
}

fragmentacion_chile <- comparar_familias_grandes(comp_chile$comparacion, chile_zbz, "Chile")
fragmentacion_japon <- comparar_familias_grandes(comp_japon$comparacion, japon_zbz, "Japón")

fragmentacion_total <- bind_rows(fragmentacion_chile, fragmentacion_japon)

# ==============================================================================
# 8. GRÁFICO: RETENCIÓN DE CADA FAMILIA (% de miembros que GK deja bajo el
#    mismo generador) vs. tamaño de la familia según ZBZ — visualiza si la
#    fragmentación empeora sistemáticamente en las secuencias más grandes.
# ==============================================================================

ggplot(fragmentacion_total, aes(x = n_replicas_zbz, y = pct_retenido_gk, colour = Pais, label = round(transMw, 1))) +
  geom_point(size = 4, alpha = 0.85) +
  geom_text(vjust = -1, size = 3.5, show.legend = FALSE) +
  scale_x_log10() +
  scale_colour_manual(values = c("Chile" = "#F8766D", "Japón" = "#619CFF")) +
  labs(
    title = "Fragmentación de familias grandes bajo Gardner-Knopoff",
    subtitle = "Cada punto es una familia ZBZ; la etiqueta es la magnitud del generador",
    x = "N° de réplicas según ZBZ (escala log)",
    y = "% de la familia que GK deja bajo el mismo generador",
    colour = "País"
  ) +
  theme_minimal(base_size = 13) +
  theme(plot.title = element_text(face = "bold"))

# ==============================================================================
# 9. EXPORTAR RESULTADOS
# ==============================================================================

write_csv(chile_gk, "chile_gardner_knopoff.csv")
write_csv(japon_gk, "japon_gardner_knopoff.csv")
write_csv(gen_chile_gk, "chile_generadores_gk.csv")
write_csv(gen_japon_gk, "japon_generadores_gk.csv")
write_csv(fragmentacion_total, "comparacion_familias_grandes_zbz_vs_gk.csv")

cat("\nListo. Archivos exportados: chile_gardner_knopoff.csv, japon_gardner_knopoff.csv, ",
    "chile_generadores_gk.csv, japon_generadores_gk.csv, comparacion_familias_grandes_zbz_vs_gk.csv\n")

# ==============================================================================
# REFERENCIAS
#
# Gardner, J. K., & Knopoff, L. (1974). Is the sequence of earthquakes in
#   Southern California, with aftershocks removed, Poissonian?. Bulletin of
#   the Seismological Society of America, 64(5), 1363-1367.
# Uhrhammer, R. A. (1986). Characteristics of northern and central
#   California seismicity. Earthquake Notes, 57(1), 21.
# Teng, G., & Baker, J. W. (2019). Seismicity declustering and hazard
#   analysis of the Oklahoma-Kansas region. Bulletin of the Seismological
#   Society of America, 109(6), 2356-2366.
# Zaliapin, I., & Ben-Zion, Y. (2020). Earthquake declustering using the
#   nearest-neighbor approach in space-time-magnitude domain.
# ==============================================================================
